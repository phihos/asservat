import json,hashlib,subprocess
from pathlib import Path
base=Path(__file__).parent;root=Path('/home/phil/Projekte/asservat-raw-packet-summary');commit='9dc9001859442333c0262c2838b8dd7ce4fbc303'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
text=(base/'dependencies.json').read_text();decoder=json.JSONDecoder();files={}
while text.strip():
 text=text.lstrip();value,n=decoder.raw_decode(text);text=text[n:];directory=Path(value.get('Dir','/missing'))
 for name in value.get('GoFiles',[])+value.get('CgoFiles',[])+value.get('EmbedFiles',[]):
  p=directory/name
  if p.is_file() and p.is_relative_to(root):files[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
for name in ('go.mod','go.sum','test/fixtures/worker-resource-probe/main.go'):files[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
bad=[]
for name,digest in files.items():
 if hashlib.sha256(subprocess.check_output(['git','show',commit+':'+name],cwd=root)).hexdigest()!=digest:bad.append(name)
assert not bad,bad
source={'commit':commit,'files':files,'commit_mismatches':bad,'scope':'Repository Go/embedded/module/fixedprobe inputs of CGO_ENABLED=0 objectstore test binary; not whole repository qualification.'}
(base/'relevant-sources.json').write_text(json.dumps(source,indent=2)+'\n')
summary={'head':commit,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'gitStatus':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'relevantSourceFiles':len(files),'mismatches':bad,'binary_sha256':hashlib.sha256((base/'raw-summary.test').read_bytes()).hexdigest(),'probe_sha256':hashlib.sha256((base/'worker-resource-probe').read_bytes()).hexdigest()}
(base/'source-before.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
