package native_test

import (
	"asservat.local/asservat/internal/application/evidence"
	"asservat.local/asservat/internal/contracts"
	query "asservat.local/asservat/internal/domain/analysis"
	"asservat.local/asservat/internal/domain/artifact"
	value "asservat.local/asservat/internal/domain/authorization"
	"asservat.local/asservat/internal/domain/identity"
	native "asservat.local/asservat/internal/transport/native"
	"context"
	"errors"
	"sync/atomic"
	"testing"
	"time"
)

// Production serving checks reread a current five-second observation. The
// original fast fixture uses a fixed observation; here it must remain current
// after the six-second reader without extending the original operation.
type temporaryCurrentServing struct{ pod string }

func (s *temporaryCurrentServing) CheckOwnerServing(context.Context) (time.Time, error) {
	return time.Now().Add(5 * time.Second), nil
}
func (s *temporaryCurrentServing) CheckNativeHub(_ context.Context, o value.NativeOperation) (time.Time, error) {
	if o.HubPodUID != s.pod || o.HubProcessEpoch != nativeID {
		return time.Time{}, artifact.ErrDownloadUnavailable
	}
	return identity.Earlier(time.Now().Add(5*time.Second), o.Until), nil
}

func TestHeavyLeaseSixSecondApprovedReadTemporary(t *testing.T) {
	started := time.Now()
	f := newProjectionProtocolFixture(t)
	now := time.Now().UTC().Truncate(time.Microsecond)
	op := f.lease.Operation
	op.StartedAt, op.Until = now, now.Add(identity.EvidenceReadRequestWindow)
	op.Processing.ObservedAt, op.Processing.ValidUntil = now, op.Until
	stored := value.NativeLease{Operation: op, Certificate: f.lease.Certificate, Sequence: 1, ObservedAt: op.StartedAt, Until: op.Until}
	f.lease = stored
	peer := value.KeyPeer{InstallationID: nativeID, PeerID: nativeID, Role: "acquisition", Certificate: stored.Certificate, NotBefore: now.Add(-time.Minute), NotAfter: now.Add(time.Minute)}
	binding := value.AcquisitionWorkerBinding{Parent: value.AcquisitionParent{Purpose: value.AcquisitionProjection, ID: op.Reference.QueryID}, InstallationID: nativeID, ClusterID: nativeID, Namespace: "private-workers", NamespaceUID: nativeID, ServiceAccount: "acquisition", ServiceAccountUID: nativeID, Job: "query", JobUID: nativeID, Pod: "query-pod", PodUID: nativeID, JobSpec: artifact.Digest{1}, PodSpec: artifact.Digest{2}}
	origin := evidence.NativeOrigin{Lease: stored, Proof: value.AcquisitionPeerProof{Binding: binding, Peer: peer, TokenDigest: artifact.Digest{4}, ObservedAt: now, FreshUntil: now.Add(identity.EvidenceReadRequestWindow)}}
	origin.Lease.Until = now.Add(5 * time.Second)
	stored0 := projectionStoredOperations{lease: stored, calls: new(atomic.Int32), revokeAt: new(atomic.Int32)}
	origins := &evidence.NativeOrigins{Projection: stored0, Now: time.Now}
	router, err := native.NewHubRouter(1)
	if err != nil {
		t.Fatal(err)
	}
	defer router.Close()
	var completed atomic.Int32
	pending, err := router.RegisterNativeExchange(f.ctx, evidence.NativeExchangeRegistration{Operation: op, Projection: &f.scope, Source: f.source, Complete: func(ctx context.Context, l value.NativeLease) error {
		completed.Add(1)
		return ctx.Err()
	}}, func(context.Context, evidence.NativeOrigin) error { return nil },
		func(bound context.Context, o evidence.NativeOrigin) (value.NativeLease, error) {
			return origins.Recheck(bound, o)
		})
	if err != nil {
		t.Fatal(err)
	}
	defer pending.Close()
	peers := &projectionWorkerPeers{origin: origin, origins: origins, hello: f.hello}
	a, err := native.NewHubWorkerAdmission(peers, &temporaryCurrentServing{pod: nativeID}, router, time.Now)
	if err != nil {
		t.Fatal(err)
	}
	var hubStep atomic.Value
	client := flowServerReporting(t, contracts.NativeWorkerPath, a, func(_ context.Context, stage string, err error) {
		var s interface{ FixedStep() string }
		if errors.As(err, &s) {
			stage += "/" + s.FixedStep()
		}
		hubStep.Store(stage)
	})
	// The fixture's frame-inspecting stream pins its own command interval;
	// this test runs the actual worker conversation on the plain stream.
	stream, err := client.Open(f.ctx, f.hello)
	if err != nil {
		t.Fatal(err)
	}
	originalReader := f.reader()
	reader := &projectionProtocolReader{read: func(ctx context.Context, source evidence.NativeContextSource, operation value.NativeOperation, scope query.ContextProjectionScope, until time.Time) (query.PodStatusProjection, error) {
		if _, err := originalReader.read(ctx, source, operation, scope, until); err != nil {
			return query.PodStatusProjection{}, err
		}
		deadline, _ := ctx.Deadline()
		t.Logf("approved reader start=%s deadline=%s operationUntil=%s initialObservationUntil=%s", time.Now().UTC().Format(time.RFC3339Nano), deadline.UTC().Format(time.RFC3339Nano), until.UTC().Format(time.RFC3339Nano), origin.Lease.Until.UTC().Format(time.RFC3339Nano))
		readStart := time.Now()
		timer := time.NewTimer(6 * time.Second)
		defer timer.Stop()
		select {
		case <-timer.C:
		case <-ctx.Done():
			return query.PodStatusProjection{}, ctx.Err()
		}
		t.Logf("approved reader elapsed=%s ctxErr=%v", time.Since(readStart), ctx.Err())
		return originalReader.read(ctx, source, operation, scope, until)
	}}
	result := f.result(t, reader)
	done := make(chan projectionProtocolOutcome, 1)
	go func() {
		defer stream.Close()
		state, err := native.RunWorkerConversation(f.ctx, stream, f.hello, f.target, artifact.Digest{1}, result)
		done <- projectionProtocolOutcome{state, err}
	}()
	exchange, err := pending.Wait(f.ctx)
	if err != nil {
		t.Fatal(err)
	}
	projection, ok := exchange.(evidence.NativeProjectionExchange)
	if !ok {
		t.Fatal("not a projection exchange")
	}
	if _, err = projection.Projection(f.ctx); err != nil {
		out := projectionProtocolReceive(t, f.ctx, done)
		var s interface{ FixedStep() string }
		step := ""
		if errors.As(out.err, &s) {
			step = s.FixedStep()
		}
		t.Fatal("projection not received", err, out.err, step, hubStep.Load())
	}
	if err = projection.AcknowledgeProjection(f.ctx); err != nil {
		t.Fatal("hub refused its own final close", err, hubStep.Load())
	}
	if out := projectionProtocolReceive(t, f.ctx, done); out.err != nil || out.state.State != contracts.NativeJoined || completed.Load() != 1 {
		t.Fatal("hub-local projection conversation did not join", out.err, completed.Load())
	}
	t.Logf("conversation joined elapsed=%s completions=%d readerCalls=%d operationObservations=%d", time.Since(started), completed.Load(), reader.calls.Load(), stored0.calls.Load())
}
