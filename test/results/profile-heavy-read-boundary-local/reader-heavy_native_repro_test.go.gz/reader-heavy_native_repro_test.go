package objectstore

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"asservat.local/asservat/internal/adapters/diagnostics"
	authapp "asservat.local/asservat/internal/application/authorization"
	"asservat.local/asservat/internal/application/evidence"
	"asservat.local/asservat/internal/contracts"
	query "asservat.local/asservat/internal/domain/analysis"
	"asservat.local/asservat/internal/domain/artifact"
	value "asservat.local/asservat/internal/domain/authorization"
	"asservat.local/asservat/internal/domain/identity"
	"github.com/aws/aws-sdk-go-v2/credentials"
)

// Temporary discriminator only: real downloaded native bytes and actual
// framing/TLS/native comparison adapter; authority/receipts/key admission are
// explicitly synthetic. No SQL, production enrollment or deployed worker.
func TestHeavyNativeReaderLocalDiscriminator(t *testing.T) {
	base := os.Getenv("ASSERVAT_HEAVY_NATIVE_REPRO")
	if base == "" {
		t.Skip("explicit retained native pair only")
	}
	names := []string{"manual-profile-5c231a44-449e-4e10-aab9-a4c87ee2bae6.pb.gz", "manual-profile-49ccf6e7-9934-428f-b036-0e74f9d6ab4e.pb.gz"}
	hashes := []string{"853f5ed2f0a6afa8c64dcef9d0715e49b9435966406cde3b108f599a63084a9d", "efd5dac937c228106a344b5bbd9b7340035f761a979bbca010b8fa6a676fae6f"}
	var fixtures [2]profileEncryptedFixture
	var dirs [2]string
	keyScope := value.KeyScope{InstallationID: testProjectionScope().RootID, Purpose: "artifact", KeyID: "synthetic"}
	for n, name := range names {
		raw, err := os.ReadFile(filepath.Join(base, name))
		if err != nil {
			t.Fatal(err)
		}
		sum := sha256.Sum256(raw)
		if hex.EncodeToString(sum[:]) != hashes[n] {
			t.Fatal("retained native hash mismatch", name)
		}
		unused, e, _ := writerFixture(t, http.NotFoundHandler())
		unused.Close()
		id := fmt.Sprintf("20000000-0000-4000-8000-%012d", n+1)
		e.NativeType, e.DataClass, e.ActionID = artifact.PprofArtifact, "raw", "a0123456789abcdef01234567"
		e.CaseID, e.CaptureUID, e.OccurrenceID = id, id, id
		e.Registration.Location.ArtifactID = id
		e.Profile = &artifact.GoProfileAcquisition{SourceRef: "synthetic-pprof", EndpointDigest: artifact.Digest{4}, Type: "cpu", Mode: "interval", DurationMillis: 10000, TimeoutMillis: 15000, MaxBytes: 16 << 20}
		e.Registration.NativeLimit = 16 << 20
		e.RequestedAgeSeconds, e.MaximumAgeSeconds = 3600, 7200
		e.Registration.ExpiresAt = e.Registration.AnchorAt.Add(time.Hour)
		e.Registration.DeleteBy = e.Registration.ExpiresAt.Add(time.Minute)
		if err := e.Validate(); err != nil {
			t.Fatal(err)
		}
		dirs[n] = t.TempDir()
		copies := prepareEncryptedProjectionSource(t, dirs[n], bytes.NewReader(raw), e, false, comparisonRemoteFixtureSealer{scope: keyScope})
		clear(raw)
		s := testProjectionScope()
		s.CaseID, s.CaptureID = e.CaseID, e.CaptureUID
		s.ArtifactID, s.ClusterID = e.Registration.Location.ArtifactID, e.Registration.Location.ClusterID
		s.NamespaceUID, s.WorkloadUID, s.PodUID = e.NamespaceUID, e.WorkloadUID, e.PodUID
		s.Version = evidence.ContextCopiesDigest(copies)
		s.NativeType, s.SourceFormat, s.DisplayVersion = artifact.PprofArtifact, artifact.PprofFormat, query.ProfileSummaryDisplayVersion
		s.Selection, s.SourceProjectionDigest, s.Profile = query.LineSelection{}, artifact.Digest{}, query.ProfileSummarySelection{SampleType: "cpu", TopN: 20}
		fixtures[n] = profileEncryptedFixture{Source: evidence.NativeContextSource{Expectation: e, Copies: copies}, Scope: s}
		if !s.Valid() || !fixtures[n].Source.Valid(s.Version) {
			t.Fatal("invalid source")
		}
	}
	for _, mode := range []string{"normal", "worker", "slow-body-normal", "slow-body-worker", "original-deadline-worker", "delayed-parser-worker"} {
		t.Run(mode, func(t *testing.T) {
			var bodyDelay, parserDelay time.Duration
			if strings.Contains(mode, "slow-body") {
				bodyDelay = 6 * time.Second
			}
			if mode == "original-deadline-worker" {
				bodyDelay = 11 * time.Second
			}
			if mode == "delayed-parser-worker" {
				parserDelay = 6 * time.Second
			}
			workerClient := strings.HasSuffix(mode, "worker") || mode == "worker"
			var mu sync.Mutex
			var ioErrors []string
			server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				for n, f := range fixtures {
					prefix := "/fixture/" + f.Source.Expectation.Registration.Location.Prefix()
					if !strings.HasPrefix(r.URL.Path, prefix) {
						continue
					}
					role := strings.TrimPrefix(r.URL.Path, prefix)
					if role != "data" && role != "index" && role != "manifest" && role != "commit" {
						w.WriteHeader(404)
						return
					}
					file, err := os.Open(filepath.Join(dirs[n], role))
					if err != nil {
						w.WriteHeader(404)
						return
					}
					defer file.Close()
					stat, _ := file.Stat()
					var from, to int64
					if _, err = fmt.Sscanf(r.Header.Get("Range"), "bytes=%d-%d", &from, &to); err != nil || from < 0 || to < from || to >= stat.Size() || r.Header.Get("If-Match") != "\"pinned\"" {
						w.WriteHeader(400)
						return
					}
					w.Header().Set("ETag", "\"pinned\"")
					w.Header().Set("Content-Range", fmt.Sprintf("bytes %d-%d/%d", from, to, stat.Size()))
					w.Header().Set("Content-Length", strconv.FormatInt(to-from+1, 10))
					w.WriteHeader(206)
					body := io.NewSectionReader(file, from, to-from+1)
					if n == 0 && role == "data" && bodyDelay > 0 {
						_, _ = io.CopyN(w, body, 1)
						w.(http.Flusher).Flush()
						select {
						case <-time.After(bodyDelay):
						case <-r.Context().Done():
							return
						}
						_, _ = io.Copy(w, body)
					} else {
						_, _ = io.Copy(w, body)
					}
					return
				}
				w.WriteHeader(404)
			}))
			defer server.Close()
			client := server.Client()
			if workerClient {
				roots := client.Transport.(*http.Transport).TLSClientConfig.RootCAs
				client = &http.Client{Transport: &http.Transport{TLSClientConfig: &tls.Config{RootCAs: roots.Clone(), MinVersion: tls.VersionTLS13, MaxVersion: tls.VersionTLS13}, DialContext: (&net.Dialer{Timeout: 5 * time.Second}).DialContext, TLSHandshakeTimeout: 5 * time.Second, ResponseHeaderTimeout: 5 * time.Second, IdleConnTimeout: 5 * time.Second, MaxConnsPerHost: 1, MaxIdleConns: 1, MaxIdleConnsPerHost: 1, MaxResponseHeaderBytes: 4096, DisableCompression: true, DisableKeepAlives: true}, Timeout: 5 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
			}
			store, err := New(server.URL, "us-east-1", "fixture", credentials.NewStaticCredentialsProvider("synthetic", "synthetic", ""), client)
			if err != nil {
				t.Fatal(err)
			}
			defer store.Close()
			actualClient := store.client.Options().HTTPClient.(*http.Client)
			if actualClient.Timeout != 30*time.Second {
				t.Fatal("production S3 constructor timeout changed", actualClient.Timeout)
			}
			actualClient.Transport = reproRoundTripper{base: actualClient.Transport, record: func(msg string) { mu.Lock(); defer mu.Unlock(); ioErrors = append(ioErrors, msg) }}
			bound, err := store.ForCustody(fixtures[0].Source.Expectation.Registration.StoreID)
			if err != nil {
				t.Fatal(err)
			}
			scope := fixtures[1].Scope
			scope.DisplayVersion = query.ProfileComparisonDisplayVersion
			s := fixtures[0].Scope
			scope.Comparison = query.ProfileComparisonWindow{Normalization: query.ProfileComparisonRate, Baseline: query.ProfileComparisonBaseline{CaseID: s.CaseID, ArtifactID: s.ArtifactID, CaptureID: s.CaptureID, ClusterID: s.ClusterID, NamespaceUID: s.NamespaceUID, WorkloadUID: s.WorkloadUID, PodUID: s.PodUID, Version: s.Version}}
			ids, _ := query.ProfileComparisonKeyChildIDs(scope.RootID)
			spent := map[string]map[string]bool{ids[0]: {}, ids[1]: {}}
			keyServer := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				request, err := contracts.DecodeKeyRequest(r.Body)
				if err != nil || request.Operation != "unwrap" || request.Sealed == nil {
					w.WriteHeader(400)
					return
				}
				mu.Lock()
				roles, ok := spent[request.AuthorityID]
				reused := ok && roles[string(request.Binding)]
				if ok && !reused {
					roles[string(request.Binding)] = true
				}
				mu.Unlock()
				if !ok || reused {
					w.WriteHeader(403)
					return
				}
				info, err := authapp.DescribeKeyRequest(value.KeyRequest{Scope: value.KeyScope{InstallationID: request.Scope.InstallationID, Purpose: request.Scope.Purpose, KeyID: request.Scope.KeyID}, AuthorityID: request.AuthorityID, Operation: request.Operation, Binding: request.Binding, Sealed: artifact.SealedKey{Reference: request.Sealed.Reference, Ciphertext: request.Sealed.Ciphertext}})
				if err != nil {
					w.WriteHeader(400)
					return
				}
				key, err := base64.StdEncoding.DecodeString(request.Sealed.Ciphertext)
				if err != nil {
					w.WriteHeader(400)
					return
				}
				defer clear(key)
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(contracts.KeyServiceResponse{Format: contracts.KeyServiceFormat, Operation: "unwrap", Output: key, RequestSHA256: hex.EncodeToString(info.RequestDigest[:]), ValidUntil: time.Now().Add(5 * time.Second).UTC().Format(time.RFC3339Nano)})
			}))
			defer keyServer.Close()
			keyClient := keyServer.Client()
			keyClient.Timeout = 5 * time.Second
			keyClient.Transport.(*http.Transport).TLSClientConfig.Certificates = []tls.Certificate{keyServer.TLS.Certificates[0]}
			reader, err := NewNativeContextReader(bound, keyScope, keyServer.URL, keyClient)
			if err != nil {
				t.Fatal(err)
			}
			var parserErr error
			var parserCalled bool
			reader.ServeProfileComparisons(func(ctx context.Context, b io.Reader, bf query.ProfileComparisonAcquisition, i io.Reader, inf query.ProfileComparisonAcquisition, selection query.ProfileComparisonSelection) (query.ProfileComparison, error) {
				parserCalled = true
				if parserDelay > 0 {
					select {
					case <-time.After(parserDelay):
					case <-ctx.Done():
						return query.ProfileComparison{}, ctx.Err()
					}
				}
				result, err := diagnostics.ComparePprof(ctx, b, bf, i, inf, selection)
				parserErr = err
				return result, err
			})
			now := time.Now().UTC()
			until := now.Add(20 * time.Second)
			rev := identity.Revision{UID: scope.RootID, Generation: 1, Digest: artifact.Digest{1}}
			path := artifact.DownloadPath{ID: scope.RootID, TargetClusterID: scope.ClusterID, StoreID: fixtures[1].Source.Expectation.Registration.StoreID, StorageRegion: "fixture", AcquisitionClusterID: scope.RootID, AcquisitionRegion: "fixture", ConnectorClusterID: scope.RootID, ConnectorRegion: "fixture", HubClusterID: scope.RootID, HubRegion: "fixture", WorkerConfiguration: rev, HubConfiguration: rev}
			proof := func(n int) artifact.DownloadProcessingProof {
				return artifact.DownloadProcessingProof{RootID: scope.RootID, Epoch: scope.RootID, CaptureID: fixtures[n].Scope.CaptureID, Location: fixtures[n].Source.Expectation.Registration.Location, Sequence: 1, StateDigest: artifact.Digest{1}, ObservedAt: now, ValidUntil: until}
			}
			o := value.NativeOperation{Path: path, Processing: proof(1), Reference: value.NativeReference{InstallationID: scope.RootID, QueryID: scope.RootID, WorkerID: scope.RootID, OperationID: scope.RootID, Fence: 1}, Kind: value.NativeProjection, HubPodUID: scope.RootID, HubProcessEpoch: scope.RootID, WorkerPodUID: scope.RootID, WorkerPublicKey: artifact.Digest{1}, SourceVersion: scope.Version, ParentID: scope.RootID, Generation: 1, StartedAt: now, Until: until, Baseline: value.NativeProjectionSource{Path: path, Processing: proof(0), SourceVersion: s.Version}}
			ctx, cancel := context.WithDeadline(t.Context(), until)
			defer cancel()
			start := time.Now()
			result, err := reader.ReadApprovedProfileComparison(ctx, [2]evidence.NativeContextSource{fixtures[0].Source, fixtures[1].Source}, o, scope, until)
			mu.Lock()
			defer mu.Unlock()
			t.Logf("mode=%s store_timeout=30s elapsed=%s error=%v parser_called=%t parser_error=%v valid=%t rows=%d source_roles=%d/%d original_context_error=%v io_errors=%v", mode, time.Since(start), err, parserCalled, parserErr, result.Valid(scope), func() int {
				if result.Comparison == nil {
					return 0
				}
				return len(result.Comparison.Rows)
			}(), len(spent[ids[0]]), len(spent[ids[1]]), ctx.Err(), ioErrors)
			if mode == "original-deadline-worker" {
				if err == nil || ctx.Err() == nil || len(ioErrors) == 0 {
					t.Fatal("original caller cutoff not retained")
				}
			} else if err != nil || !result.Valid(scope) || result.Comparison == nil || len(result.Comparison.Rows) != 20 {
				t.Fatal("full native comparison failed", err)
			}
			result.Clear()
		})
	}
}

type reproRoundTripper struct {
	base   http.RoundTripper
	record func(string)
}

func (r reproRoundTripper) RoundTrip(q *http.Request) (*http.Response, error) {
	start := time.Now()
	response, err := r.base.RoundTrip(q)
	if err != nil {
		r.record(fmt.Sprintf("roundtrip role=%s elapsed=%s error_type=%T", filepath.Base(q.URL.Path), time.Since(start), err))
		return response, err
	}
	response.Body = &reproBody{ReadCloser: response.Body, start: start, role: filepath.Base(q.URL.Path), record: r.record}
	return response, nil
}

type reproBody struct {
	io.ReadCloser
	start  time.Time
	role   string
	record func(string)
}

func (r *reproBody) Read(b []byte) (int, error) {
	n, err := r.ReadCloser.Read(b)
	if err != nil && !errors.Is(err, io.EOF) {
		var timeout net.Error
		r.record(fmt.Sprintf("body role=%s elapsed=%s error_type=%T timeout=%t", r.role, time.Since(r.start), err, errors.As(err, &timeout) && timeout.Timeout()))
	}
	return n, err
}
