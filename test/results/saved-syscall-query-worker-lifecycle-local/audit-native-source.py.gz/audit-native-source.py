#!/usr/bin/env python3
"""One-off readback of native environment source hashes against one Git commit."""
import hashlib,json,re,subprocess,sys
from pathlib import Path
repo,commit,report,output=sys.argv[1:]
assert re.fullmatch(r'[0-9a-f]{40}',commit)
r=json.loads(Path(report).read_text())
p=subprocess.Popen(['git','-C',repo,'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
mismatches=[]
try:
 for path,wanted in r['sourceHashes'].items():
  assert '\n' not in path and '\r' not in path and not Path(path).is_absolute() and '..' not in Path(path).parts
  p.stdin.write((commit+':'+path+'\n').encode());p.stdin.flush()
  head=p.stdout.readline().decode().strip().split()
  if len(head)!=3 or head[1]!='blob':
   raise ValueError('Missing Git source '+path)
  length=int(head[2]);body=p.stdout.read(length)
  assert len(body)==length and p.stdout.read(1)==b'\n'
  got=hashlib.sha256(body).hexdigest()
  if got!=wanted:mismatches.append({'path':path,'reported':wanted,'git':got})
 p.stdin.close();assert p.wait()==0
except BaseException:
 p.kill();p.wait();raise
out={'commit':commit,'report':str(report),'reportSHA256':hashlib.sha256(Path(report).read_bytes()).hexdigest(),'sourceCount':len(r['sourceHashes']),'mismatches':mismatches,'sourceUnchangedDuringTest':r.get('sourceUnchangedDuringTest'),'goTestExit':r.get('goTestExit'),'testExit':r.get('testExit'),'providerLogExit':r.get('providerLogExit'),'buildScratchRemoved':r.get('buildScratchRemoved'),'cleanupFailures':r.get('cleanupFailures'),'passedTests':r.get('passedTests')}
Path(output).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
assert not mismatches
