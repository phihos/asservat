# Two-source encrypted profile comparison process probe

Final frozen test binary SHA-256: `0523c5f4fe3da7351a8a89c14bedfaad44ab668228ab936f856078a65f6ecd88`. Owned new test source SHA-256: `4d68876682747ff195f7d4751557ae1c7e411c3b4431cea9789f2967300d6d80`. Full input/native/protobuf/cipher and per-process source hashes are in `report.json`, `process-*.json`, and the two consumer JSON reports.

| Current consumer | Peak RSS | Wall | User CPU | System CPU | Exit |
| --- | ---: | ---: | ---: | ---: | ---: |
| Original 1-value / 0-label pair | 191.266 MiB | 1.202 s | 1.200296 s | 0.042777 s | 0 |
| Heavy 16-value / 32768-label pair | 252.363 MiB | 1.202 s | 1.270287 s | 0.049424 s | 0 |

Both final runs returned20 valid rows, used six synthetic unwraps, closed both sources, and kept binary/input/source inventory hashes unchanged and equal to the frozen build inputs. The heavy pair passed unchanged publisher preflight on its first generated shape. Per source:100000 functions,100000 locations,100000 samples,1048576 frame visits,16 types/values per sample,32768 numeric labels with units,662144 shared object units,100021 strings, and16777160 decompressed bytes. Native gzip baseline9394862 bytes, incident9392922 bytes. Original immutable pair has1 value/sample and0 labels; its native/cipher bytes were reused unchanged. Its producer used the earlier binary, explicitly recorded separately.

Only3.637 MiB observed RSS headroom remains below256 MiB for the heavy pair. This does not establish deployed256 MiB feasibility, hard-container containment,500m CPU timing, production SQL/KMS behavior or all accepted shapes. TLS fixture provider allocation is included; producer graph/encryption allocation is excluded by fresh processes. GOMAXPROCS2/GOGC100, no GOMEMLIMIT, forced GC, resource-limit changes or production changes.

Frozen inventory:3814 tracked and untracked nonignored repository Go files, go.mod/go.sum and internal JSON files. It does not cover the full repository or module cache. Earlier cached probe results were binary-bound only because one domain file changed between producer and consumer; final consumers use the newly built frozen inventory.

The earlier cancellation run is retained separately under `../profile-comparison-memory-198ea528/`; it is not presented as a current-source rerun. No broad gates or external services were run, and no commits were made.

## Single authorized soft-limit follow-up

Same final binary and immutable heavy inputs, with standard `GOMEMLIMIT=224MiB`, `GOGC=100` and `GOMAXPROCS=2`: exit0; peakRSS252060KiB=246.152MiB; wall1.201681s; process userCPU1.297455s +systemCPU0.046800s. Operation1.139275s, operationCPU1.261595u+0.038496s. Six synthetic unwraps,20 valid rows,both sources closed. Source inventory still exactly matches all3814 frozen build inputs; binary/source/input hashes unchanged before/after.

This one replay reduced observed peakRSS by6.211MiB relative to the prior no-limit heavy run, leaving9.848MiB below256MiB. CPU sum increased from1.319711s to1.344255s (~1.86%); single-run variation prevents treating that delta as an established cost. The standard Go memory limit is soft, does not cap process/containerRSS and does not qualify a256MiB deployment. No product/config/source edits or additional shape campaigns. Exact env and hashes are in `process-complete-heavy-224m.json` and `complete-heavy-224m.json`.
