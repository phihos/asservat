import hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
repo=Path('/home/phil/Projekte/asservat-profile-comparison')
cache=Path('/home/phil/.cache/asservat-build/profile-comparison-memory-final')
old_inputs=Path('/home/phil/.cache/asservat-build/profile-comparison-memory-198ea528/fixtures')
binary=cache/'objectstore.test'
phase=sys.argv[1]
if phase not in ('generate-heavy','complete-original','complete-heavy'):raise SystemExit('closed phase required')
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while data:=f.read(1<<20):h.update(data)
 return h.hexdigest()
def sources():
 names=subprocess.run(['git','ls-files','--cached','--others','--exclude-standard','*.go','go.mod','go.sum','internal/**/*.json'],cwd=repo,check=True,capture_output=True,text=True).stdout.splitlines()
 names.append('internal/adapters/objectstore/profile_comparison_memory_test.go')
 return {n:digest(repo/n) for n in sorted(set(names))}
def inputs():
 root=old_inputs if phase=='complete-original' else cache/'fixtures-heavy'
 return {str(p.relative_to(root)):digest(p) for p in sorted(root.rglob('*')) if p.is_file()} if root.exists() else {}
code_before=sources(); input_before=inputs(); binary_before=digest(binary)
build_inputs=json.loads((cache/'build-source-before.json').read_text())['hashes']
if code_before!=build_inputs:raise SystemExit('Source inventory changed after frozen build; no qualification run')
env=os.environ.copy()
for name in list(env):
 if name.startswith('ASSERVAT_PROFILE_COMPARISON_') or name=='GOMEMLIMIT':env.pop(name)
env.update({'TMPDIR':'/home/phil/.cache/asservat-build/tmp','GOMAXPROCS':'2','GOGC':'100'})
if phase=='generate-heavy':env.update({'ASSERVAT_PROFILE_COMPARISON_GENERATE':str(cache/'fixtures-heavy'),'ASSERVAT_PROFILE_COMPARISON_HEAVY':'1'})
else:env.update({'ASSERVAT_PROFILE_COMPARISON_FIXTURE':str(old_inputs if phase=='complete-original' else cache/'fixtures-heavy'),'ASSERVAT_PROFILE_COMPARISON_MODE':'complete','ASSERVAT_PROFILE_COMPARISON_REPORT':str(cache/(phase+'.json'))})
args=[str(binary),'-test.run','^TestProfileComparisonEncryptedProcess$','-test.v','-test.timeout','150s']
started=time.monotonic()
with (cache/(phase+'.log')).open('wb') as log:
 p=subprocess.Popen(args,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 timed_out=False
 while True:
  pid,status,usage=os.wait4(p.pid,os.WNOHANG)
  if pid:break
  if time.monotonic()-started>=160:
   timed_out=True;os.killpg(p.pid,signal.SIGKILL);pid,status,usage=os.wait4(p.pid,0);break
  time.sleep(.1)
 p.returncode=os.waitstatus_to_exitcode(status)
report={'phase':phase,'command':args,'exit_code':p.returncode,'timeout':timed_out,'wall_seconds':time.monotonic()-started,'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,'peak_rss_kib':usage.ru_maxrss,'binary_sha256':binary_before,'binary_unchanged':digest(binary)==binary_before,'source_hashes':code_before,'sources_unchanged':sources()==code_before,'matches_build_source_inventory':code_before==build_inputs,'input_hashes_before':input_before,'input_hashes_after':inputs(),'inputs_unchanged':None if phase=='generate-heavy' else inputs()==input_before,'configuration':{'GOMAXPROCS':2,'GOGC':100,'GOMEMLIMIT':None,'cgroup_memory_limit':None,'cpu_quota':None},'scope':'Owned separate generator/consumer processes. Generator allocations excluded from consumers. Loopback TLS fixture providers share consumer. Frozen tracked and untracked repository Go/module/internal-JSON inventory, not a whole-repo/module-cache freeze. No resource containment or real SQL/KMS/deployed-worker qualification.'}
(cache/('process-'+phase+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('phase','exit_code','timeout','wall_seconds','user_cpu_seconds','system_cpu_seconds','peak_rss_kib','binary_sha256','binary_unchanged','sources_unchanged','inputs_unchanged')},indent=2))
if p.returncode!=0:print((cache/(phase+'.log')).read_text()[-4000:])
raise SystemExit(p.returncode)
