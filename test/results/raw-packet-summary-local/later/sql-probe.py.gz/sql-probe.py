import pathlib,subprocess,json,hashlib,shutil,time,uuid
root=pathlib.Path('/home/phil/Projekte/asservat-raw-packet-summary'); cache=pathlib.Path('/home/phil/.cache/asservat-build/raw-packet-summary'); staged=cache/'138-migrations';staged.mkdir(exist_ok=True)
for p in (root/'migrations').glob('[0-9]*.sql'):shutil.copyfile(p,staged/p.name)
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(staged.glob('*.sql'))}; assert len(hashes)==138
name='asservat-raw-packet138-'+uuid.uuid4().hex[:10]
report={'scope':'SQL-only function/source/accounting/rollback expressions; not runtime roles, Go sourcefreeze or installed evidence','sourceBase':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'migrationSHA256':hashes,'container':name,'steps':[],'cleanupFailures':[]}
def run(label,args,sql=None,expected=0):
 r=subprocess.run(args,input=sql,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=cache/('138-'+label+'.log');log.write_text(r.stdout);report['steps'].append({'label':label,'command':args,'stdinSHA256':hashlib.sha256(sql.encode()).hexdigest() if sql else None,'exit':r.returncode,'log':str(log)});assert r.returncode==expected,(label,r.returncode,r.stdout[-1500:]);return r.stdout
psql=['docker','exec','-i',name,'psql','-U','postgres','-v','ON_ERROR_STOP=1','-tA']
goose=['docker','exec',name,'/tmp/goose','-dir','/migrations','postgres','user=postgres dbname=postgres host=/var/run/postgresql sslmode=disable']
scope={'NativeType':'rawPcapng','SourceFormat':'pcapng-raw','DisplayVersion':'approved-raw-pcap-summary/v1','Selection':{'LineStart':0,'MaxLines':0},'SourceProjectionDigest':[0]*32}
expr=lambda s:"'"+json.dumps(s,separators=(',',':'))+"'::jsonb"
red="DO $$BEGIN IF NOT public.context_query_scope_source_valid("+expr(scope)+") THEN RAISE EXCEPTION 'desired raw summary source unsupported at137'; END IF;END$$;"
def checks():
 cases=[(scope,True)]
 for k,v in [('NativeType','pcapng'),('SourceFormat','pcapng'),('DisplayVersion','approved-pcap-summary/v1'),('Selection',{'LineStart':1,'MaxLines':1}),('Profile',{}),('Headers',{}),('Comparison',{}),('Syscalls',{}),('SourceProjectionDigest',[1]*32)]:
  bad=scope.copy();bad[k]=v;cases.append((bad,False))
 for k in ['Selection','SourceFormat','DisplayVersion','SourceProjectionDigest']:
  bad=scope.copy();del bad[k];cases.append((bad,False))
 meta=dict(scope,NativeType='pcapng',SourceFormat='pcapng',DisplayVersion='approved-pcap-summary/v1');cases.append((meta,True))
 sql='DO $$BEGIN\n'
 for s,want in cases:sql+='IF public.context_query_scope_source_valid('+expr(s)+') IS DISTINCT FROM '+str(want).lower()+" THEN RAISE EXCEPTION 'closed raw/metadata source mismatch';END IF;\n"
 sql+='IF public.context_query_units('+expr(scope)+")<>2 OR public.context_query_read_batches("+expr(scope)+")<>1 OR public.context_query_begin_tool("+expr(scope)+")<>'get_pcap_summary' THEN RAISE EXCEPTION 'raw accounting/tool mismatch';END IF; END$$;"
 return sql
names=['public.context_query_scope_source_valid(jsonb)','public.context_query_begin_tool(jsonb)','public.context_query_read_batches(jsonb)','public.context_query_units(jsonb)','public.guard_context_query()']
defs="SELECT jsonb_object_agg(f,pg_get_functiondef(f::regprocedure)) FROM unnest(ARRAY["+','.join("'"+n+"'" for n in names)+"]) f;"
inputs={'red':red,'green':checks(),'definitions':defs};(cache/'138-probe-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');report['inputsSHA256']=hashlib.sha256((cache/'138-probe-inputs.json').read_bytes()).hexdigest()
try:
 run('start',['docker','run','-d','--network','none','--tmpfs','/var/lib/postgresql/data:rw,size=256m','-e','PGDATA=/var/lib/postgresql/data','-e','POSTGRES_HOST_AUTH_METHOD=trust','--name',name,'--mount',f'type=bind,src={staged},dst=/migrations,readonly','postgres@sha256:afc7e2d441324c0388fa80c3d24f733b4194a4eb7f47dd8ee2b08eb1a24a647c','-c','shared_buffers=16MB','-c','max_connections=20'])
 for _ in range(100):
  readylog=subprocess.run(['docker','logs',name],capture_output=True,text=True)
  if 'PostgreSQL init process complete; ready for start up.' in readylog.stdout+readylog.stderr and subprocess.run(['docker','exec',name,'pg_isready','-U','postgres'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:break
  time.sleep(.1)
 else:raise RuntimeError('postgres readiness')
 run('copy-goose',['docker','cp','/home/phil/.cache/asservat-build/bin/goose',name+':/tmp/goose'])
 run('up137',goose+['up-to','137']);before=run('137-definitions',psql,defs)
 run('source-red137',psql,red,3)
 run('up138',goose+['up']);run('expression-green',psql,checks())
 run('down137',goose+['down-to','137']);after=run('restored137-definitions',psql,defs);assert before==after;report['exact137FunctionsRestored']=True
 run('up138-after-down',goose+['up']);run('expression-green-after-down',psql,checks())
 report['sourceSQLUnchanged']=all(hashlib.sha256((root/'migrations'/n).read_bytes()).hexdigest()==h for n,h in hashes.items());assert report['sourceSQLUnchanged']
 report['result']='pass'
finally:
 try:run('postgres',['docker','logs',name])
 except Exception as e:report['diagnosticError']=str(e)
 try:run('cleanup',['docker','rm','-f','-v',name])
 except Exception as e:report['cleanupFailures'].append(str(e))
 left=subprocess.check_output(['docker','ps','-a','--filter','name='+name,'--format','{{.Names}}'],text=True).strip();report['remainingContainers']=left;assert not left
 (cache/'138-probe-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['result','exact137FunctionsRestored','sourceSQLUnchanged','cleanupFailures','remainingContainers']}))
