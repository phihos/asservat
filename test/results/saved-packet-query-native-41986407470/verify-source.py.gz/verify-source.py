import argparse,hashlib,json,pathlib,subprocess
p=argparse.ArgumentParser();p.add_argument('environment',type=pathlib.Path);p.add_argument('commit');p.add_argument('output',type=pathlib.Path);p.add_argument('--expect-go-exit',type=int,default=0);p.add_argument('--expect-harness-exit',type=int,default=0);a=p.parse_args()
d=json.loads(a.environment.read_text());sources=d['sourceHashes'];assert sources
specs=[a.commit+':'+name for name in sources]
r=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(specs)+'\n').encode(),capture_output=True,check=True)
b=r.stdout;at=0;bad=[]
for name,expected in sources.items():
 end=b.index(b'\n',at);h=b[at:end].decode().split();assert len(h)==3 and h[1]=='blob',(name,h)
 size=int(h[2]);start=end+1;data=b[start:start+size];assert len(data)==size and b[start+size:start+size+1]==b'\n';at=start+size+1
 actual=hashlib.sha256(data).hexdigest()
 if actual!=expected:bad.append({'path':name,'expected':expected,'actual':actual})
assert at==len(b)
out={'source_commit':a.commit,'environment_sha256':hashlib.sha256(a.environment.read_bytes()).hexdigest(),'source_files':len(sources),'mismatches':bad,'goTestExit':d.get('goTestExit'),'testExit':d.get('testExit'),'sourceUnchangedDuringTest':d.get('sourceUnchangedDuringTest'),'buildScratchRemoved':d.get('buildScratchRemoved'),'cleanupFailures':d.get('cleanupFailures'),'passedTests':d.get('passedTests'),'journeyFocus':d.get('journeyFocus'),'scope':'Exact Git blob readback for all reported inputs; runtime, native parity and terminal assertions require their original logs separately.'}
a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
assert not bad
assert d.get('goTestExit')==a.expect_go_exit and d.get('testExit')==a.expect_harness_exit
assert d.get('sourceUnchangedDuringTest') is True and d.get('buildScratchRemoved') is True
assert d.get('cleanupFailures')==[]
