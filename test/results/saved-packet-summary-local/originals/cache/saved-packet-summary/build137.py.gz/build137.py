from pathlib import Path
import re
root=Path('/home/phil/Projekte/asservat-saved-packet-summary')
names=['context_query_scope_source_valid','context_query_begin_tool','context_query_read_batches','context_query_units','operation_audit_lane','operation_audit_human_input_valid','guard_operation_audit','context_query_intent_current','context_query_outcome_closed','guard_context_query']
old={}
for p in sorted((root/'migrations').glob('[0-9]*.sql')):
 if int(p.name.split('_')[0])>136: continue
 up=p.read_text().split('-- +goose Down')[0]
 for n in names:
  m=re.search(r'CREATE (?:OR REPLACE )?FUNCTION '+n+r'\(.*?-- \+goose StatementEnd',up,re.S)
  if m: old[n]=m[0]
assert len(old)==len(names)
new=dict(old)
n='context_query_scope_source_valid'
anchor=" IF NOT (s ? 'Comparison') THEN RETURN public.context_query_scope_source_valid_legacy133(s); END IF;"
assert anchor in new[n]
new[n]=new[n].replace(anchor,''' -- Saved packet metadata has no caller-controlled selection or projection.
 IF s->>'NativeType'='pcapng' THEN
  RETURN COALESCE(NOT (s ? 'Headers') AND NOT (s ? 'Profile') AND NOT (s ? 'Syscalls') AND NOT (s ? 'Comparison') AND
   s->>'SourceFormat'='pcapng' AND s->>'DisplayVersion'='approved-pcap-summary/v1' AND
   s->'Selection'='{"LineStart":0,"MaxLines":0}'::jsonb AND s->'SourceProjectionDigest'=to_jsonb(array_fill(0,ARRAY[32])),false);
 END IF;
'''+anchor)
new['context_query_begin_tool']=new['context_query_begin_tool'].replace("SELECT CASE WHEN s ? 'Comparison'", "SELECT CASE WHEN s->>'NativeType'='pcapng' THEN 'get_pcap_summary' WHEN s ? 'Comparison'")
new['context_query_units']=new['context_query_units'].replace("('httpHeaders','syscallRecords','syscallArguments')", "('httpHeaders','syscallRecords','syscallArguments','pcapng')")
new['context_query_read_batches']=new['context_query_read_batches'].replace("('httpHeaders','pprof','syscallRecords','syscallArguments')", "('httpHeaders','pprof','syscallRecords','syscallArguments','pcapng')")
for n in ['operation_audit_lane','operation_audit_human_input_valid','guard_operation_audit','context_query_intent_current','context_query_outcome_closed']:
 assert "'get_profile_summary'" in new[n],n
 new[n]=new[n].replace("'get_profile_summary'", "'get_profile_summary','get_pcap_summary'")
new['guard_context_query']=new['guard_context_query'].replace("('pprof','syscallRecords','syscallArguments')", "('pprof','syscallRecords','syscallArguments','pcapng')")
for n in names: assert new[n]!=old[n],n
wrap=lambda s:'-- +goose StatementBegin\n'+s+'\n'
text='''-- +goose Up
-- ADR-303: one paid, metadata-only summary of an already saved PCAPNG source.
-- Reuse the existing query, worker, audit and three one-use key roles. No new
-- state or privileges; source publication/current authority retains class/size.
'''+''.join(wrap(new[n]) for n in names)+'''
-- +goose Down
-- An earlier binary cannot decode retained packet queries or their audit input.
-- +goose StatementBegin
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM public.context_query WHERE query->'Scope'->>'NativeType'='pcapng') OR
    EXISTS(SELECT 1 FROM public.operation_audit WHERE intent->>'Name'='get_pcap_summary') THEN
  RAISE EXCEPTION 'saved packet query history cannot be downgraded' USING ERRCODE='55000';
 END IF;
END $$;
-- +goose StatementEnd
'''+''.join(wrap(old[n]) for n in reversed(names))
(root/'migrations/00137_saved_packet_summary.sql').write_text(text)
p=root/'internal/adapters/postgres/custody.go';p.write_text(p.read_text().replace('const currentSchemaVersion = 136','const currentSchemaVersion = 137'))
p=root/'migrations/README.md';p.write_text(p.read_text().replace('requires schema version 136','requires schema version 137'))
print('wrote',len(text),'bytes; exact previous functions retained in Down')
