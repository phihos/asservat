from pathlib import Path
import json,hashlib,gzip,subprocess
cache=Path('/home/phil/.cache/asservat-build');root=Path('/home/phil/Projekte/asservat-saved-packet-summary');stage=cache/'packet-summary-local-archive-staging';stage.mkdir(exist_ok=True)
files=[]
import shutil
shutil.rmtree(stage/'originals',ignore_errors=True)
def add(p,kind):
 if not p.is_file():return
 try:rel=Path('cache')/p.relative_to(cache)
 except ValueError:rel=Path('service')/p.name
 raw=p.read_bytes();target=stage/'originals'/rel.parent/(rel.name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('wb')as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=9)as z:z.write(raw)
 packed=target.read_bytes();assert gzip.decompress(packed)==raw
 files.append({'path':str(target.relative_to(stage)),'original':str(p),'kind':kind,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'gzipBytes':len(packed),'gzipSHA256':hashlib.sha256(packed).hexdigest()})
for p in sorted(cache.glob('packet-summary-*.json')):add(p,'original handoff/freeze/provenance')
for p in sorted(cache.glob('packet-summary-*.log')):add(p,'original local component/gate log; outcomes only as recorded by its handoff or rootcommands')
for p in sorted(cache.glob('packet-summary-*.sha256')):add(p,'original source hashes')
for p in sorted((cache/'packet-summary-console-browser-output').rglob('report.json')):add(p,'fullconsole browser generated report, root copied after actualterminal0; image screenshots intentionally omitted')
for p in sorted((cache/'saved-packet-summary').iterdir()):
 if p.is_file()and p.suffix in ['.json','.log','.sha256','.py','.sql']:add(p,'DB/native local original; historical source scope in handoff')
for name in ['packet-summary-lifecycle','packet-summary-upgrade137']:
 for suffix in ['.log','-environment.json']:add(cache/'saved-packet-summary/service-originals'/(name+suffix),'frozen6eee realservice original, moved unchanged from owned test/results report after verified preservation')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='6eee3964a6fb00c85490eee0aba2368964b1dc7a'
provenance={'frozenServiceSource':head,'frozenServiceTree':subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=root,text=True).strip(),'baseBeforePacket':'4c0d23e3d95a5f93a025d1ffb5ce0ed4539ebb71','earlySnapshots':'Six handoffs preserve their own dirty/shared source hashes and exact commands; do not attribute earlier runs to final commit. Original handoff remaining-work statements predate subsequent service passes.','serviceCommands':[{'cwd':str(root),'env':{'PATH':'/home/phil/.cache/asservat-build/spec-venv/bin:/home/phil/.cache/asservat-build/bin:$INHERITED_PATH','TMPDIR':str(cache/'tmp'),'GOTMPDIR':str(cache/'tmp'),'GOFLAGS':'-buildvcs=false -p=2'},'command':f"python scripts/test-custody.py --fleet --run '^{test}$' --result-name {name}",'harnessExit':0,'goPackageSeconds':elapsed,'sourceHashesVerified':4137,'sourceUnchanged':True,'cleanupFailures':[]}for test,name,elapsed in [('TestPacketSummaryLifecycleWithRealServices','packet-summary-lifecycle',9.166),('TestCustodyUpgradeSchemaWithRealPostgres','packet-summary-upgrade137',7.339)]],'localLimits':['SQL/S3/KMS compiled-role fixture with controlled synthetic source/human/Job/Pod/issuer/join inputs; not installed authority or native collection','Existing parser/canonical verifier/authenticated framed reader components are local tests; no wholeworker/cgroup maximum qualification','Built GoTLS/React tests are local synthetic authority; installed MCP/React/same-native tshark qualification pending','Host tshark unavailable in pure parity test; exact numeric field/PCAPNG independent decoder checked without actual local tshark CLI','No paid VM/CI/native dispatch or publication claimed by this archive'],'rootTerminalEvidence':'full console-browser-check actual0/83.053s at6eee, five selectedtests; rootcommands original records full command/env. Initialprepush68ba remains2; correctedgate0 and integratedpreflight0 are separate.', 'files':len(files)}
(stage/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
(stage/'manifest.json').write_text(json.dumps({'format':'asservat-local-evidence-archive/v1','entries':files},indent=2)+'\n')
(stage/'README.md').write_text('''# Saved packet summary: local evidence

Frozen service source: `6eee3964a6fb00c85490eee0aba2368964b1dc7a`.
Earlier local handoffs/logs retain their own shared/dirty snapshots and exact
scope. They are not retroactive qualifications of this final commit.

The two separate pristine service campaigns passed: compiled packet lifecycle
Go9.166s and upgrade137 Go7.339s. Every reported4137 source SHA256 per campaign
matches that commit's Git blob bytes; both report unchanged source and empty
cleanupFailures. The lifecycle uses actual compiled runtime/key SQL roles and
managed verified publication, with explicitly synthetic Job/Pod/issuer/join
inputs. Upgrade checks restore exact136 and retained133–136 contracts.

Original RED/setup failures remain alongside corrections, including closedSQL136,
parser semantics, public audit timing, advancing response observations in both
Go/browser fixtures, and the stale gate-selector assertion. The initial whole
pre-push exited2; corrected target passes do not relabel it a whole-command pass.

No installed packet-summary, live collection, native tshark, cgroup or broad
maximum-shape qualification is claimed here. Host tshark was absent; local
parity exercised numeric fields plus the independent PCAPNG decoder. Browser
proof uses built React with synthetic local authority. Full console-browser gate exited0/83.053s on6eee: five selected tests, including
the new packet browser and existing28journeys/27accessibility scans. Its
original stable log, root command metadata and copied report JSONs are retained;
screenshots are omitted to keep this local archive small.

`manifest.json` records original and deterministic-gzip SHA256/lengths. Every
compressed member was decompressed and checked against its original bytes.
''')
print(json.dumps({'stage':str(stage),'originals':len(files),'gzipBytes':sum(x['gzipBytes']for x in files),'readback':'all exact','terminalEvidence':provenance['rootTerminalEvidence']}))
