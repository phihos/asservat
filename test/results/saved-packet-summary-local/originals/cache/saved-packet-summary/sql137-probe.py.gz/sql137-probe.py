import pathlib,subprocess,hashlib,json,time,uuid,shutil
root=pathlib.Path('/home/phil/Projekte/asservat-saved-packet-summary');cache=pathlib.Path(__file__).parent;src=cache/'137-migrations';src.mkdir(exist_ok=True)
files=sorted((root/'migrations').glob('[0-9]*.sql'));assert len(files)==137
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
for p in files:shutil.copyfile(p,src/p.name)
name='asservat-packet137-sql-'+uuid.uuid4().hex[:10];report={'scope':'network-isolated cached PostgreSQL/goose SQL expression probe only; not runtime-role/service qualification','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sql_hashes':hashes,'container':name,'steps':[],'cleanupFailures':[]}
def run(args,label,input=None,check=True):
 p=subprocess.run(args,input=input,capture_output=True);(cache/(label+'.log')).write_bytes(p.stdout+p.stderr);report['steps'].append({'command':args,'exit':p.returncode,'log':str(cache/(label+'.log'))})
 if check and p.returncode:raise RuntimeError(label+' failed '+str(p.returncode))
 return p
try:
 run(['docker','run','-d','--network','none','--tmpfs','/var/lib/postgresql/data:rw,size=256m','-e','PGDATA=/var/lib/postgresql/data','-e','POSTGRES_HOST_AUTH_METHOD=trust','--name',name,'--mount','type=bind,src='+str(src)+',dst=/migrations,readonly','postgres@sha256:afc7e2d441324c0388fa80c3d24f733b4194a4eb7f47dd8ee2b08eb1a24a647c','-c','shared_buffers=16MB','-c','max_connections=20'],'137-start')
 for _ in range(50):
  if subprocess.run(['docker','exec',name,'pg_isready','-U','postgres','-d','postgres'],capture_output=True).returncode==0:break
  time.sleep(.3)
 else:raise RuntimeError('PostgreSQL not ready')
 run(['docker','cp','/home/phil/.cache/asservat-build/bin/goose',name+':/tmp/goose'],'137-copy-goose')
 run(['docker','exec',name,'/tmp/goose','-dir','/migrations','postgres','user=postgres dbname=postgres host=/var/run/postgresql sslmode=disable','up'],'137-up136')
 definitions="SELECT string_agg(pg_get_functiondef(oid),E'\\n' ORDER BY proname) FROM pg_proc WHERE pronamespace='public'::regnamespace AND proname IN ('context_query_scope_source_valid','context_query_begin_tool','context_query_read_batches','context_query_units','operation_audit_lane','operation_audit_human_input_valid','guard_operation_audit','context_query_intent_current','context_query_outcome_closed','guard_context_query')"
 sqlcheck=(cache/'sql137-check.sql').read_bytes()
 cmd=['docker','exec','-i',name,'psql','-U','postgres','-d','postgres','-v','ON_ERROR_STOP=1','-tA']
 run(cmd,'137-expression-green',input=sqlcheck)
 run(['docker','exec',name,'/tmp/goose','-dir','/migrations','postgres','user=postgres dbname=postgres host=/var/run/postgresql sslmode=disable','down-to','136'],'137-down136')
 restored=run(cmd,'137-down-functions',input=definitions.encode()).stdout
 # Compare with Up136 on a pristine second database in the same isolated server.
 run(cmd,'137-create-control',input=b'CREATE DATABASE control;')
 run(['docker','exec',name,'/tmp/goose','-dir','/migrations','postgres','user=postgres dbname=control host=/var/run/postgresql sslmode=disable','up-to','136'],'137-control-up136')
 control=run([*cmd[:-2],'-d','control','-tA'],'137-control-functions',input=definitions.encode()).stdout
 assert restored==control,'Down failed exact previous function parity'
 run(['docker','exec',name,'/tmp/goose','-dir','/migrations','postgres','user=postgres dbname=postgres host=/var/run/postgresql sslmode=disable','up'],'137-up-after-down')
 run(cmd,'137-repeated-expression-green',input=sqlcheck)
 report['exactPreviousFunctionsRestored']=True
 report['expression_exit']=0

finally:
 run(['docker','logs',name],'137-postgres',check=False)
 p=run(['docker','rm','-f','-v',name],'137-cleanup',check=False)
 if p.returncode:report['cleanupFailures'].append('container removal failed')
 report['sourceSQLUnchanged']=hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
 (cache/'137-probe-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'expression_exit':report.get('expression_exit'),'exactPreviousFunctionsRestored':report.get('exactPreviousFunctionsRestored'),'sourceSQLUnchanged':report['sourceSQLUnchanged'],'cleanupFailures':report['cleanupFailures']}))
