from pathlib import Path
p=Path('test/integration/installer_continuation_native_test.go');s=p.read_text();old='\t\t\t\t\tqualifyInstalledApprovedRecording(t, ctx, identity, publicRoot, publicAddress, origin, cluster, namespace, workload, f.Clusters[1].Config, diagnose, measurement,';start=s.index(old)
insert='''                    summaryCheck:=installedProjectionSQLCheck(t,ctx,admin,api,p.RootID)
                    if installedJourneyFocus()=="manual-mixed" {summaryCheck=installedPacketSummarySQLCheck(t,ctx,admin,api,p.RootID)}
'''
s=s[:start]+insert+s[start:];start=s.index(old);a=s.index('installedProjectionSQLCheck(t, ctx, admin, api, p.RootID)',start);s=s[:a]+'summaryCheck'+s[a+len('installedProjectionSQLCheck(t, ctx, admin, api, p.RootID)'):];p.write_text(s)
p=Path('test/integration/installed_approved_recording_native_test.go');s=p.read_text()
old='\t\tfor n, a := range evidence.Artifacts {\n\t\t\tnative, extension :='
new='''        for n,a:=range evidence.Artifacts {
            var packetMCP,packetBrowser *analysis.PacketSummary
            if a.NativeFormat==artifact.PCAPNGFormat {
                if a.DataClass!="metadata" || a.Kind!="packetCapture" || a.Target.PodUID!=preview.Pods[0].UID {t.Fatal("mixed packet source changed original metadata target")}
                source:=installedPacketSummarySource{CaseID:progress.CaseID,ArtifactID:a.ID,Version:a.Digest,PodUID:preview.Pods[0].UID,Expires:a.Expires}
                mcp:=queryInstalledPacketSummary(t,ctx,identity,transport,origin,source,summaryCheck)
                console:=queryInstalledPacketSummaryBrowser(t,ctx,browser,address,source,summaryCheck)
                packetMCP,packetBrowser=&mcp,&console
            }
            native, extension :='''
assert old in s;s=s.replace(old,new,1)
old='''				if out, err := exec.CommandContext(ctx, "tshark", "-r", path, "-T", "fields", "-e", "tcp.port").Output(); err != nil || strings.TrimSpace(string(out)) == "" {
					t.Fatal("mixed PCAPNG did not open in tshark with real traffic", err)
				}'''
assert old in s;s=s.replace(old,'''                if packetMCP==nil||packetBrowser==nil{t.Fatal("mixed packet source was not summarized before native download")}
                installedPacketSummaryTshark(t,ctx,path,native,*packetMCP)
                installedPacketSummaryTshark(t,ctx,path,native,*packetBrowser)''',1)
s=s.replace('"asservat.local/asservat/internal/contracts"','"asservat.local/asservat/internal/contracts"\n analysis "asservat.local/asservat/internal/domain/analysis"',1)
p.write_text(s)
