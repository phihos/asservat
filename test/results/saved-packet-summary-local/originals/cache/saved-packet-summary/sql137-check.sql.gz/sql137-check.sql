DO $$
DECLARE s jsonb:='{"NativeType":"pcapng","SourceFormat":"pcapng","DisplayVersion":"approved-pcap-summary/v1","Selection":{"LineStart":0,"MaxLines":0},"SourceProjectionDigest":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}'; k text; bad jsonb;
BEGIN
 IF NOT public.context_query_scope_source_valid(s) OR public.context_query_units(s)<>2 OR public.context_query_read_batches(s)<>1 OR public.context_query_begin_tool(s)<>'get_pcap_summary' THEN RAISE EXCEPTION 'packet scope/accounting mismatch'; END IF;
 FOREACH k IN ARRAY ARRAY['Headers','Profile','Syscalls','Comparison'] LOOP
  bad:=s||jsonb_build_object(k,'{}'::jsonb);
  IF public.context_query_scope_source_valid(bad) THEN RAISE EXCEPTION 'extra selection accepted: %',k; END IF;
  bad:=s||jsonb_build_object(k,'null'::jsonb);
  IF public.context_query_scope_source_valid(bad) THEN RAISE EXCEPTION 'null selection accepted: %',k; END IF;
 END LOOP;
 FOREACH k IN ARRAY ARRAY['NativeType','SourceFormat','DisplayVersion','Selection','SourceProjectionDigest'] LOOP
  IF public.context_query_scope_source_valid(s-k) THEN RAISE EXCEPTION 'missing field accepted: %',k; END IF;
 END LOOP;
 FOREACH bad IN ARRAY ARRAY[s||'{"NativeType":"rawPcapng"}'::jsonb,s||'{"SourceFormat":"raw-pcapng"}'::jsonb,s||'{"DisplayVersion":"approved-pcap-summary/v2"}'::jsonb,s||'{"Selection":{"LineStart":1,"MaxLines":0}}'::jsonb,s||'{"SourceProjectionDigest":[1]}'::jsonb] LOOP
  IF public.context_query_scope_source_valid(bad) THEN RAISE EXCEPTION 'source/selector mutation accepted'; END IF;
 END LOOP;
 IF public.operation_audit_lane('get_pcap_summary') IS DISTINCT FROM 'normal' OR NOT public.operation_audit_human_input_valid('get_pcap_summary','context-query-input/v1') OR public.operation_audit_human_input_valid('get_pcap_summary','context-input/v1') OR public.operation_audit_lane('get_pcap_summary_v2') IS NOT NULL THEN RAISE EXCEPTION 'audit tool/format mismatch'; END IF;
END $$;
