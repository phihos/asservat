import json,hashlib,subprocess,pathlib,re
root=pathlib.Path('/home/phil/Projekte/asservat-saved-packet-summary');cache=pathlib.Path(__file__).parent;sha='6eee3964a6fb00c85490eee0aba2368964b1dc7a'
reports=[]
for name in ['packet-summary-lifecycle','packet-summary-upgrade137']:
 path=root/'test/results'/f'{name}-environment.json';d=json.loads(path.read_text());log=(root/'test/results'/f'{name}.log').read_text();proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE);bad=[];count=0
 for path,expected in d['sourceHashes'].items():
  proc.stdin.write((sha+':'+path+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip().split()
  if len(header)!=3 or header[1]!='blob':bad.append({'path':path,'error':'missing blob'});continue
  content=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n';actual=hashlib.sha256(content).hexdigest()
  if actual!=expected:bad.append({'path':path,'expected':expected,'gitSha256':actual})
  count+=1
 proc.stdin.close();assert proc.wait()==0
 runs=re.findall(r'^=== RUN   (.+)$',log,re.M);passed=re.findall(r'^\s*--- PASS: (\S+) ',log,re.M)
 report={'name':name,'source':sha,'goPackageResult':re.findall(r'^ok\s+[^\n]+$',log,re.M),'goTestExit':d['testExit'],'harnessExit':0,'sourceReportedUnchanged':d['sourceUnchangedDuringTest'],'cleanupFailures':d['cleanupFailures'],'reportedSourceCount':len(d['sourceHashes']),'verifiedGitBlobCount':count,'mismatches':bad,'actualRUNCount':len(runs),'actualPASSCount':len(passed),'passedTestNames':d['passedTestNames'],'phases':d['phases'],'environmentFileSHA256':hashlib.sha256((root/'test/results'/f'{name}-environment.json').read_bytes()).hexdigest(),'logFileSHA256':hashlib.sha256(log.encode()).hexdigest()};reports.append(report)
 assert not bad and d['testExit']==0 and d['sourceUnchangedDuringTest'] and not d['cleanupFailures'] and len(runs)==len(passed)
subprocess.run(['git','status','--short'],cwd=root,check=True)
(cache/'service-source-verification.json').write_text(json.dumps({'scope':'independent comparison of every reported service-fixture SHA256 to frozen Git blob bytes; SQL/S3 compiled-role qualification, not installed/native authority','source':sha,'reports':reports},indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items()if k in ['name','goPackageResult','goTestExit','harnessExit','reportedSourceCount','verifiedGitBlobCount','actualRUNCount','actualPASSCount','mismatches','cleanupFailures']}for r in reports],indent=2))
