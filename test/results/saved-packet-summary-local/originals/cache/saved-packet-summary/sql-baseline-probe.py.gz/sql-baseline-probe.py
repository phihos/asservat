import pathlib,subprocess,hashlib,json,time,uuid,shutil
root=pathlib.Path('/home/phil/Projekte/asservat-saved-packet-summary');cache=pathlib.Path(__file__).parent;src=cache/'baseline-migrations';src.mkdir(exist_ok=True)
files=sorted((root/'migrations').glob('[0-9]*.sql'));assert len(files)==136
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
for p in files:shutil.copyfile(p,src/p.name)
name='asservat-packet137-sql-'+uuid.uuid4().hex[:10];report={'scope':'network-isolated cached PostgreSQL/goose SQL expression probe only; not runtime-role/service qualification','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sql_hashes':hashes,'container':name,'steps':[],'cleanupFailures':[]}
def run(args,label,input=None,check=True):
 p=subprocess.run(args,input=input,capture_output=True);(cache/(label+'.log')).write_bytes(p.stdout+p.stderr);report['steps'].append({'command':args,'exit':p.returncode,'log':str(cache/(label+'.log'))})
 if check and p.returncode:raise RuntimeError(label+' failed '+str(p.returncode))
 return p
try:
 run(['docker','run','-d','--network','none','--tmpfs','/var/lib/postgresql/data:rw,size=256m','-e','PGDATA=/var/lib/postgresql/data','-e','POSTGRES_HOST_AUTH_METHOD=trust','--name',name,'--mount','type=bind,src='+str(src)+',dst=/migrations,readonly','postgres@sha256:afc7e2d441324c0388fa80c3d24f733b4194a4eb7f47dd8ee2b08eb1a24a647c','-c','shared_buffers=16MB','-c','max_connections=20'],'baseline-start')
 for _ in range(50):
  if subprocess.run(['docker','exec',name,'pg_isready','-U','postgres','-d','postgres'],capture_output=True).returncode==0:break
  time.sleep(.3)
 else:raise RuntimeError('PostgreSQL not ready')
 run(['docker','cp','/home/phil/.cache/asservat-build/bin/goose',name+':/tmp/goose'],'baseline-copy-goose')
 run(['docker','exec',name,'/tmp/goose','-dir','/migrations','postgres','user=postgres dbname=postgres host=/var/run/postgresql sslmode=disable','up'],'baseline-up136')
 scope={'NativeType':'pcapng','SourceFormat':'pcapng','DisplayVersion':'approved-pcap-summary/v1','Selection':{'LineStart':0,'MaxLines':0},'SourceProjectionDigest':[0]*32}
 sql="DO $$ BEGIN IF public.context_query_scope_source_valid('"+json.dumps(scope)+"'::jsonb) IS DISTINCT FROM true THEN RAISE EXCEPTION 'saved packet summary source remains closed'; END IF; END $$;"
 p=run(['docker','exec','-i',name,'psql','-U','postgres','-d','postgres','-v','ON_ERROR_STOP=1'], 'baseline-packet-source-red',input=sql.encode(),check=False);report['desired_source_exit']=p.returncode
 assert p.returncode==3,'baseline unexpectedly accepts new route'
finally:
 run(['docker','logs',name],'baseline-postgres',check=False)
 p=run(['docker','rm','-f','-v',name],'baseline-cleanup',check=False)
 if p.returncode:report['cleanupFailures'].append('container removal failed')
 report['sourceSQLUnchanged']=hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
 (cache/'baseline-probe-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'desired_source_exit':report.get('desired_source_exit'),'sourceSQLUnchanged':report['sourceSQLUnchanged'],'cleanupFailures':report['cleanupFailures']}))
