import hashlib,io,json,pathlib,subprocess
b=pathlib.Path(__file__).parent;r=pathlib.Path('/home/phil/Projekte/asservat-saved-syscall-query');qualified='0cf27e86a0ad0477fb220a2d09e56908545ba87e'
s=json.loads((b/'relevant-sources.json').read_text());before=json.loads((b/'source-0cf-before.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();names=list(s['files'])
for commit in dict.fromkeys([qualified,head]):
 out=subprocess.run(['git','cat-file','--batch'],input=''.join(commit+':'+p+'\n' for p in names).encode(),cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);stream=io.BytesIO(out.stdout)
 for name in names:
  h=stream.readline().decode().strip().split();assert len(h)==3 and h[1]=='blob',name
  content=stream.read(int(h[2]));assert stream.read(1)==b'\n'
  assert hashlib.sha256(content).hexdigest()==s['files'][name],name
  assert hashlib.sha256((r/name).read_bytes()).hexdigest()==s['files'][name],name
 assert not stream.read()
for name,v in s['overlay_files'].items():assert hashlib.sha256(pathlib.Path(v['source']).read_bytes()).hexdigest()==v['sha256'],name
assert hashlib.sha256((b/'syscall-query.test').read_bytes()).hexdigest()==before['binary_sha256']
assert hashlib.sha256((b/'worker-resource-probe').read_bytes()).hexdigest()==before['probe_sha256']
fixture=json.loads((b/'encrypted-inputs/probe.json').read_text());fixture_hashes={}
for item in fixture['Inputs']:
 for name,want in item['Files'].items():
  p=b/'encrypted-inputs'/item['Shape']/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==want,str(p);fixture_hashes[str(p.relative_to(b))]=want
reports=json.loads((b/'matrix.json').read_text());assert len(reports)==4
cases=[]
for report in reports:
 shape,mode=report['shape'],report['mode'];folder=b/(shape+'-'+mode);actual=json.loads((folder/'docker-inspect.json').read_text())[0];component=json.loads((folder/'component.json').read_text());start=json.loads((folder/'cgroup-before.json').read_text());end=json.loads((folder/'cgroup-after.json').read_text())
 assert actual['State']==report['state']
 assert not actual['State']['Running'] and not actual['State']['OOMKilled'] and actual['State']['ExitCode']==0
 assert all(report[k]==0 for k in ('create_exit','start_exit','consumer-exit','probe-exit','cleanup_exit'))
 assert report['component_success'] and report['relevant_source_unchanged_before'] and report['relevant_source_unchanged_after']
 assert actual['HostConfig']['Memory']==256<<20 and actual['HostConfig']['MemorySwap']==256<<20 and actual['HostConfig']['NanoCpus']==500000000
 assert actual['HostConfig']['NetworkMode']=='none' and actual['HostConfig']['ReadonlyRootfs'] and not actual['HostConfig']['Privileged'] and actual['HostConfig']['CapDrop']==['ALL'] and actual['Config']['User']=='1000:1000'
 for mount in actual['Mounts']:
  if mount['Destination'] in ('/syscall-query.test','/resource-probe','/fixture'):assert not mount['RW']
 for probe in (start,end):
  assert probe['binary_sha256']==before['probe_sha256']
  assert probe['memory_max']=={'value':256<<20,'unlimited':False} and probe['swap_max']=={'value':0,'unlimited':False}
  assert probe['swap_current']==0 and probe['cpu_quota']=={'value':50000,'unlimited':False} and probe['cpu_period']==100000
  assert all(probe['memory_events'][k]==0 for k in ('max','oom','oom_kill','oom_group_kill'))
 assert component['binary_sha256']==before['binary_sha256'] and component['conversation_bound_ns']==20000000000
 assert component['receiver_joined'] and component['synthetic_unwraps']==3
 assert component['gomaxprocs']==2 and component['gogc']=='100' and not component['gomemlimit']
 if mode=='complete':assert component['result_valid'] and component['expected_shape_match'] and not component['read_failed'] and component['total_matching']==component['input']['Records'] and 0<component['rows']<=100 and component['page_encoded_bytes']<=20480
 else:assert component['read_failed'] and not component['result_valid'] and component['rows']==component['page_encoded_bytes']==0
 if mode=='cancel':assert component['cancel_join_ns']>0
 log=(folder/'consumer.log').read_text();assert '=== RUN   TestRawSyscallQueryEncryptedResourceProcess' in log and '\nPASS\n' in log
 cases.append({'shape':shape,'mode':mode,'consumer_exit':report['consumer-exit'],'container_exit':actual['State']['ExitCode'],'probe_exit':report['probe-exit'],'cleanup_exit':report['cleanup_exit'],'operation_elapsed_ns':component['operation_elapsed_ns'],'rows':component['rows'],'page_encoded_bytes':component['page_encoded_bytes'],'full_saved_records':component['input']['Records'],'total_matching':component['total_matching'],'read_failed':component['read_failed'],'receiver_joined':component['receiver_joined'],'synthetic_unwraps':component['synthetic_unwraps'],'cancel_join_ns':component['cancel_join_ns'],'memory_peak_bytes':end['memory_peak'],'memory_current_at_after_probe':end['memory_current'],'process_peak_rss_kib':component['process_peak_rss_kib'],'memory_events':end['memory_events'],'swap_current':end['swap_current'],'cgroup_probe_elapsed_ns':int((__import__('datetime').datetime.fromisoformat(end['observed_at'].replace('Z','+00:00'))-__import__('datetime').datetime.fromisoformat(start['observed_at'].replace('Z','+00:00'))).total_seconds()*1e9),'cgroup_cpu_usage_delta_usec':end['cpu_stat']['usage_usec']-start['cpu_stat']['usage_usec'],'cgroup_cpu_periods_delta':end['cpu_stat']['nr_periods']-start['cpu_stat']['nr_periods'],'cgroup_cpu_throttled_periods_delta':end['cpu_stat']['nr_throttled']-start['cpu_stat']['nr_throttled'],'cgroup_throttled_usec_delta':end['cpu_stat']['throttled_usec']-start['cpu_stat']['throttled_usec'],'container_started_at':actual['State']['StartedAt'],'container_finished_at':actual['State']['FinishedAt']})
cleanup=subprocess.run(['docker','ps','-a','--filter','label=asservat-syscall-query-resource=owned','--format','{{.ID}}'],capture_output=True,text=True);assert cleanup.returncode==0 and not cleanup.stdout.strip()
(b/'cleanup-final-readback.json').write_text(json.dumps({'command':cleanup.args,'exit':cleanup.returncode,'ids':cleanup.stdout.splitlines(),'stderr':cleanup.stderr},indent=2)+'\n')
after={'observed_head':head,'compared_qualified_commit':qualified,'verified_git_inputs':len(names),'overlay_inputs':s['overlay_files'],'mismatches':[],'binary_sha256':before['binary_sha256'],'probe_sha256':before['probe_sha256'],'fixture_hashes':fixture_hashes,'all_immutable_after_consumers':True}
(b/'source-0cf-after.json').write_text(json.dumps(after,indent=2)+'\n')
result={'format':'raw-syscall-query-resource-audit/v1','result':'PASS for four named component cases','qualified_source_commit':qualified,'binary_build_source_commit':s['commit'],'source_equivalence':'All1821compiledGitinputs +explicit cache-only overlay unchanged before/after, exact0cf commit bytes.','input_count':len(names),'overlay_count':len(s['overlay_files']),'binary_sha256':before['binary_sha256'],'probe_sha256':before['probe_sha256'],'native_shapes':json.loads((b/'native-shapes-independent-audit.json').read_text()),'cases':cases,'highest_memory_peak_bytes':max(c['memory_peak_bytes'] for c in cases),'memory_limit_bytes':256<<20,'swap_limit_bytes':0,'cpu':'500m CONFIGURATION ONLY. Short samples show0throttled periods and CPU usage exceeds0.5ofwall; do not claim effective/sustained CPU enforcement, throughput or capacity.','producer':'Separate host process; original producer allocation/RSS is excluded from consumers. Providers share measured consumer process.','cleanup_exit':cleanup.returncode,'owned_containers_remaining':0,'limits':['Synthetic source/grant/key authority; no SQL/realKMS proof.','Actual approved receiver→outer NativeContextReader→canonical raw parser/framed authentication/TLS range+three distinct scoped keyRPCs are included.','No publicC20/browser/nativeowner command wire/workerbootstrap/enrollment/installedmaximum-input acquisition qualification.','Two near8MiB sources, not exact8MiB or theoretical8192-byte lines/4096-byte values.','Process rusageMaxRSS and cgroup memory.peak are separate retained observations; no analyzer-only attribution.'],'method':'Cache audit read actual original per-case files/inspect/probes, verified all hashes and exact selectedRUN+PASS, then final owned-label Dockerps read. No consumer rerun.'}
p=b/'final-audit.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'result':result['result'],'cases':len(cases),'compiled_git_inputs':len(names),'highest_memory_peak_bytes':result['highest_memory_peak_bytes'],'owned_containers_remaining':0}))
