import json,hashlib,subprocess,os,io
from pathlib import Path
base=Path(__file__).parent;root=Path('/home/phil/Projekte/asservat-saved-syscall-query');commit='33131ddff1adf670ead8efc4a699ad6360171599'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
replacements=json.loads((base/'overlay.json').read_text())['Replace'];overlay_files={}
text=(base/'dependencies.json').read_text();decoder=json.JSONDecoder();files={}
while text.strip():
 text=text.lstrip();value,n=decoder.raw_decode(text);text=text[n:];directory=Path(value.get('Dir','/missing'))
 for name in value.get('GoFiles',[])+value.get('CgoFiles',[])+value.get('EmbedFiles',[])+value.get('TestGoFiles',[])+value.get('XTestGoFiles',[]):
  p=directory/name
  if str(p) in replacements:
   actual=Path(replacements[str(p)]);overlay_files[str(p.relative_to(root))]={'source':str(actual),'sha256':hashlib.sha256(actual.read_bytes()).hexdigest(),'bytes':actual.stat().st_size}
  elif p.is_file() and p.is_relative_to(root):files[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
assert len(overlay_files)==1,overlay_files
for name in ('go.mod','go.sum','test/fixtures/worker-resource-probe/main.go'):files[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
names=list(files);readback=subprocess.run(['git','cat-file','--batch'],input=''.join(commit+':'+name+'\n' for name in names).encode(),cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);stream=io.BytesIO(readback.stdout);bad=[]
for name in names:
 header=stream.readline().decode().strip().split()
 if len(header)!=3 or header[1]!='blob':raise RuntimeError('Git blob missing: '+name)
 body=stream.read(int(header[2]));assert stream.read(1)==b'\n'
 if hashlib.sha256(body).hexdigest()!=files[name]:bad.append(name)
assert not stream.read();assert not bad,bad
source={'commit':commit,'files':files,'overlay_files':overlay_files,'commit_mismatches':bad,'scope':'CGO0 objectstore test binary Go/embedded/module +fixedprobe Git inputs, plus explicit cache-only additional test overlay. Not whole repository or installed qualification.'}
(base/'relevant-sources.json').write_text(json.dumps(source,indent=2)+'\n')
summary={'head':commit,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'gitStatus':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'relevantSourceFiles':len(files),'overlay_files':overlay_files,'mismatches':bad,'binary_sha256':hashlib.sha256((base/'syscall-query.test').read_bytes()).hexdigest(),'probe_sha256':hashlib.sha256((base/'worker-resource-probe').read_bytes()).hexdigest()}
(base/'source-before.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
