package objectstore

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"testing"
	"time"

	"asservat.local/asservat/internal/adapters/objectstore/manifest"
	"asservat.local/asservat/internal/adapters/syscalls"
	"asservat.local/asservat/internal/application/evidence"
	query "asservat.local/asservat/internal/domain/analysis"
	"asservat.local/asservat/internal/domain/artifact"
	value "asservat.local/asservat/internal/domain/authorization"
)

type syscallQueryResourceInput struct {
	Shape                                                string
	Records, NativeBytes                                 int64
	NativeSHA256                                         string
	MaximumLineBytes, SelectedNames, ReturnedBufferBytes int
	Files                                                map[string]string
}
type syscallQueryResourceFixture struct {
	BinarySHA256 string
	Inputs       []syscallQueryResourceInput
}

// Cache-only test overlay: no product API or repository test input is modified.
func TestRawSyscallQueryEncryptedResourceProcess(t *testing.T) {
	if dir := os.Getenv("ASSERVAT_SYSCALL_QUERY_RESOURCE_GENERATE"); dir != "" {
		syscallQueryResourceGenerate(t, dir)
		return
	}
	dir := os.Getenv("ASSERVAT_SYSCALL_QUERY_RESOURCE_FIXTURE")
	if dir == "" {
		t.Skip("explicit prepared raw syscall resource component")
	}
	shape, mode := os.Getenv("ASSERVAT_SYSCALL_QUERY_RESOURCE_SHAPE"), os.Getenv("ASSERVAT_SYSCALL_QUERY_RESOURCE_MODE")
	if mode != "complete" && mode != "cancel" && mode != "source-error" {
		t.Fatal("explicit mode required")
	}
	var prepared syscallQueryResourceFixture
	comparisonProbeLoad(t, filepath.Join(dir, "probe.json"), &prepared)
	exe, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	binarySHA, _ := comparisonProbeDigest(t, exe)
	if binarySHA != prepared.BinarySHA256 {
		t.Fatal("producer/consumer binary differs")
	}
	var input *syscallQueryResourceInput
	for i := range prepared.Inputs {
		if prepared.Inputs[i].Shape == shape {
			input = &prepared.Inputs[i]
		}
	}
	if input == nil {
		t.Fatal("unknown prepared shape")
	}
	for name, want := range input.Files {
		got, _ := comparisonProbeDigest(t, filepath.Join(dir, shape, name))
		if got != want {
			t.Fatal("immutable fixture changed", name)
		}
	}
	var f profileEncryptedFixture
	comparisonProbeLoad(t, filepath.Join(dir, shape, "fixture.json"), &f)
	if input.NativeBytes > artifact.RecordingNativeLimit || input.NativeBytes < artifact.RecordingNativeLimit-8192 || input.MaximumLineBytes > syscalls.MaxArgumentLine || !f.Scope.Valid() || f.Scope.Syscalls.NameCount != input.SelectedNames {
		t.Fatal("prepared bounds changed")
	}
	until := time.Now().Add(value.NativeConversationWindow(value.NativeProjection))
	ctx, cancel := context.WithDeadline(t.Context(), until)
	defer cancel()
	var before, after syscall.Rusage
	if err = syscall.Getrusage(syscall.RUSAGE_SELF, &before); err != nil {
		t.Fatal(err)
	}
	started := time.Now()
	result, readErr, roles, joined, cancelJoin := savedPacketProbeRead(t, ctx, cancel, filepath.Join(dir, shape), f, mode, func(r *NativeContextReader) { r.ServeSyscallQueries(syscalls.QuerySyscallArguments) })
	if err = syscall.Getrusage(syscall.RUSAGE_SELF, &after); err != nil {
		t.Fatal(err)
	}
	valid := readErr == nil && result.Valid(f.Scope)
	rows, pageBytes, total := 0, 0, 0
	expected := false
	if valid && result.SyscallQuery != nil {
		page := result.SyscallQuery
		rows, pageBytes, total = len(page.Events), page.EncodedSize(), page.TotalMatching
		expected = rows > 0 && rows <= query.SyscallPageRecords && pageBytes <= query.SyscallQueryPageBytes && int64(page.RecordCount) == input.Records && int64(total) == input.Records && page.Next(f.Scope.Syscalls.Selection(f.Scope.CaseID, f.Scope.ArtifactID), f.Scope.Version) != ""
		if shape == "widest-values-64names" {
			expected = expected && rows < query.SyscallPageRecords && len(page.Events[0].Arguments) == 4 && page.Events[0].Arguments[3].Value == "base64:"+base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{0x9d}, 128)) && page.Events[0].Arguments[3].Truncated
		}
	}
	var memory runtime.MemStats
	runtime.ReadMemStats(&memory)
	report := map[string]any{"format": "raw-syscall-query-resource-component/v1", "shape": shape, "mode": mode, "binary_sha256": binarySHA, "input": input, "go_version": runtime.Version(), "gomaxprocs": runtime.GOMAXPROCS(0), "gogc": os.Getenv("GOGC"), "gomemlimit": os.Getenv("GOMEMLIMIT"), "operation_elapsed_ns": time.Since(started).Nanoseconds(), "operation_user_cpu_ns": comparisonProbeCPU(after.Utime) - comparisonProbeCPU(before.Utime), "operation_system_cpu_ns": comparisonProbeCPU(after.Stime) - comparisonProbeCPU(before.Stime), "process_peak_rss_kib": after.Maxrss, "heap_inuse": memory.HeapInuse, "command_until": until, "conversation_bound_ns": value.NativeConversationWindow(value.NativeProjection).Nanoseconds(), "synthetic_unwraps": roles, "receiver_joined": joined, "cancel_join_ns": cancelJoin, "result_valid": valid, "expected_shape_match": expected, "read_failed": readErr != nil, "rows": rows, "page_encoded_bytes": pageBytes, "total_matching": total, "scope": "Actual approved receiver, NativeContextReader, startup-installed raw syscall parser, complete canonical/framed authentication and local TLS range/key RPC. Synthetic current source/key/grant authority. Providers share consumer process. No SQL, real KMS, public/C20, native command/owner wire, worker bootstrap/enrollment or installed/acquisition maximum-input claim. External runner alone observes cgroup limits/counters;500m configuration does not demonstrate sustained CPU enforcement."}
	if path := os.Getenv("ASSERVAT_SYSCALL_QUERY_RESOURCE_REPORT"); path != "" {
		comparisonProbeWrite(t, path, report)
	}
	if !joined || roles != 3 {
		t.Fatal("exact three scoped unwraps and joined receiver required", roles, joined)
	}
	if mode == "complete" && !expected || mode != "complete" && (readErr == nil || result.SyscallQuery != nil || result.InvalidCursor || result.TooLarge) {
		t.Fatal("complete EOF/page or fail-closed contract", mode)
	}
	result.Clear()
}

func syscallQueryResourceGenerate(t *testing.T, dir string) {
	t.Helper()
	if err := os.MkdirAll(dir, 0700); err != nil {
		t.Fatal(err)
	}
	exe, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	binarySHA, _ := comparisonProbeDigest(t, exe)
	prepared := syscallQueryResourceFixture{BinarySHA256: binarySHA}
	for _, shape := range []string{"many-small", "widest-values-64names"} {
		folder := filepath.Join(dir, shape)
		if err = os.MkdirAll(folder, 0700); err != nil {
			t.Fatal(err)
		}
		keyScope := value.KeyScope{InstallationID: testProjectionScope().RootID, Purpose: "artifact", KeyID: "synthetic"}
		sealer := comparisonRemoteFixtureSealer{scope: keyScope}
		f := prepareSyscallEncryptedFixture(t, folder, "arguments", false, false, false, sealer)
		e := f.Source.Expectation
		syscallName := "close"
		if shape == "widest-values-64names" {
			syscallName = "pwrite64"
		}
		e.Recording.Syscalls.Names = []string{syscallName}
		definitions, err := syscalls.ArgumentDefinitions(e.Recording.Syscalls.Names, true, 128)
		if err != nil {
			t.Fatal(err)
		}
		e.Recording.Arguments.DefinitionDigest = artifact.Digest(syscalls.ArgumentDefinitionDigest(definitions))
		e.Recording.Arguments.MaxProbeBytes = int64(syscalls.ArgumentMaxProbeBytes(definitions))
		// Enough synthetic observation credit for the existing100k events/s ceiling;
		// no claim that this file qualifies that acquisition rate is made.
		e.Recording.Arguments.MaxBytesPerSecond = e.Recording.Arguments.MaxProbeBytes * e.Recording.Syscalls.MaxEventsPerSecond
		if err = e.Validate(); err != nil {
			t.Fatal(err)
		}
		a := e.Recording.Arguments
		header := artifact.ArgumentHeader{Record: "header", Format: syscalls.ArgumentNativeFormat, PodUID: e.PodUID, NodeUID: e.NodeUID, CollectorPodUID: e.CaptureUID, SessionID: e.CaptureUID, Fence: e.CaptureUID, BootID: e.NodeBootID, SourceEpoch: e.CaptureUID, EngineDigest: hex.EncodeToString(a.ProgramDigest[:]), DefinitionDigest: hex.EncodeToString(a.DefinitionDigest[:]), AccountingRule: hex.EncodeToString(a.AccountingRule[:]), Decoder: syscalls.ArgumentDecoderVersion, ABI: syscalls.ABI, StartedAt: e.TriggeredAt}
		suffix := "@" + header.BootID + "@" + header.SourceEpoch
		duration := uint64(1)
		event := artifact.RawArgumentEvent{Identity: artifact.ArgumentIdentity{PodUID: e.PodUID, ProcessRef: "p:1:1" + suffix, ThreadRef: "t:1:1" + suffix}, Syscall: syscallName, ABI: syscalls.ABI, Timestamp: e.TriggeredAt.Format(time.RFC3339Nano), DurationNS: &duration, Outcome: "success", Arguments: []artifact.ArgumentValue{{Name: "fd", Value: "decimal:0"}}}
		if shape == "widest-values-64names" {
			event.Identity.ProcessRef = "p:4294967295:18446744073709551615" + suffix
			event.Identity.ThreadRef = "t:4294967295:18446744073709551615" + suffix
			duration = 999999999
			event.Outcome, event.Errno = "error", "EAGAIN"
			event.Arguments = []artifact.ArgumentValue{{Name: "fd", Value: "decimal:-2147483648"}, {Name: "count", Value: "decimal:18446744073709551615"}, {Name: "offset", Value: "decimal:-9223372036854775808"}, {Name: "buffer", Value: "base64:" + base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{0x9d}, 128)), Truncated: true}}
		}
		native, err := syscalls.AppendArgumentLine(nil, header)
		if err != nil {
			t.Fatal(err)
		}
		line, err := syscalls.AppendArgumentLine(nil, artifact.ArgumentEventLine{Record: "event", Event: event})
		if err != nil {
			t.Fatal(err)
		}
		input := syscallQueryResourceInput{Shape: shape, MaximumLineBytes: len(line) - 1}
		// Leave only enough room for the actual finite footer, without fake padding.
		for int64(len(native)+len(line)+1024) <= artifact.RecordingNativeLimit {
			native = append(native, line...)
			input.Records++
		}
		footer := artifact.ArgumentFooter{Record: "footer", EndedAt: e.TriggeredAt.Add(time.Second), Outcome: "completed", Retained: uint64(input.Records), CoverageUnknown: true}
		if shape == "widest-values-64names" {
			footer.Truncated = uint64(input.Records)
			input.ReturnedBufferBytes = 128
		}
		native, err = syscalls.AppendArgumentLine(native, footer)
		if err != nil {
			t.Fatal(err)
		}
		contracts, err := manifest.New()
		if err != nil {
			t.Fatal(err)
		}
		check, err := contracts.NativeCheck(e, manifest.ContextManifest{StartedAt: e.TriggeredAt, CompletedAt: e.TriggeredAt.Add(time.Second)})
		if err != nil {
			t.Fatal(err)
		}
		if err = check.Write(native); err == nil {
			err = check.Close()
		}
		if err != nil {
			t.Fatal("canonical prepared source", err)
		}
		f.Source.Expectation = e
		f.Source.Copies = prepareEncryptedProjectionSource(t, folder, bytes.NewReader(native), e, false, sealer)
		f.Scope.Version = evidence.ContextCopiesDigest(f.Source.Copies)
		f.Scope.DisplayVersion, f.Scope.RawGrantID = query.SyscallQueryDisplayVersion, f.Scope.RootID
		names := []string(nil)
		if shape == "widest-values-64names" {
			names = append(names, syscallName)
			for i := 0; i < 63; i++ {
				names = append(names, strings.Repeat("<", 62)+fmt.Sprintf("%02d", i))
			}
		}
		selection, err := query.NormalizeSyscallSelection(f.Scope.CaseID, f.Scope.ArtifactID, query.SyscallQueryView, "", 100, names, false)
		if err != nil {
			t.Fatal(err)
		}
		f.Scope.Syscalls = selection.Window()
		input.SelectedNames = len(names)
		if !f.Scope.Valid() || !f.Source.Valid(f.Scope.Version) {
			t.Fatal("invalid prepared scope/source")
		}
		// The fixed parser must also accept the complete canonical native before it
		// is handed to the independent consumer; producer allocations stay outside.
		page, err := syscalls.QuerySyscallArguments(t.Context(), bytes.NewReader(native), e, e.TriggeredAt, e.TriggeredAt.Add(time.Second), selection, f.Scope.Version)
		if err != nil || page.SyscallQuery == nil || int64(page.SyscallQuery.RecordCount) != input.Records {
			t.Fatal("prepared query source", err)
		}
		page.Clear()
		if err = os.WriteFile(filepath.Join(folder, "native.arguments.jsonl"), native, 0600); err != nil {
			t.Fatal(err)
		}
		comparisonProbeWrite(t, filepath.Join(folder, "fixture.json"), f)
		input.NativeSHA256, input.NativeBytes = comparisonProbeDigest(t, filepath.Join(folder, "native.arguments.jsonl"))
		input.Files = map[string]string{}
		for _, name := range []string{"native.arguments.jsonl", "data", "index", "manifest", "commit", "fixture.json"} {
			input.Files[name], _ = comparisonProbeDigest(t, filepath.Join(folder, name))
		}
		prepared.Inputs = append(prepared.Inputs, input)
		clear(native)
	}
	comparisonProbeWrite(t, filepath.Join(dir, "probe.json"), prepared)
}
