import json,subprocess,time,hashlib,os
from pathlib import Path
base=Path(__file__).parent;root=Path('/home/phil/Projekte/asservat-saved-syscall-query')
image='sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e'
inventory=json.loads((base/'relevant-sources.json').read_text())
def unchanged():
 bad=[p for p,s in inventory['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=s]
 bad += [p for p,v in inventory.get('overlay_files',{}).items() if hashlib.sha256(Path(v['source']).read_bytes()).hexdigest()!=v['sha256']]
 if bad:raise RuntimeError('relevant source changed: '+repr(bad))
 return True
def run(cmd,timeout=30):return subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
unchanged()
image_read=run(['docker','image','inspect',image]);(base/'image-inspect.json').write_text(image_read.stdout)
if image_read.returncode:raise SystemExit(image_read.stderr)
reports=[]
for shape,mode in [('many-small','complete'),('widest-values-64names','complete'),('widest-values-64names','cancel'),('widest-values-64names','source-error')]:
 unchanged();folder=base/(shape+'-'+mode);folder.mkdir(mode=0o700,exist_ok=True)
 name='asservat-syscall-query-'+shape+'-'+mode+'-'+str(time.time_ns())
 shell='/resource-probe > /output/cgroup-before.json 2> /output/probe-before-error.log; before=$?; if [ "$before" -ne 0 ]; then exit "$before"; fi; /syscall-query.test -test.run=^TestRawSyscallQueryEncryptedResourceProcess$ -test.v -test.timeout=3m > /output/consumer.log 2>&1; consumer=$?; /resource-probe > /output/cgroup-after.json 2> /output/probe-error.log; probe=$?; printf "%s\\n" "$consumer" > /output/consumer-exit; printf "%s\\n" "$probe" > /output/probe-exit; exit "$consumer"'
 cmd=['docker','create','--pull=never','--name',name,'--label','asservat.packet-query-resource=owned','--network=none','--read-only','--tmpfs','/tmp:rw,nosuid,nodev,noexec,size=64m,mode=1777','--memory=256m','--memory-swap=256m','--cpus=0.5','--cap-drop=ALL','--user','1000:1000']
 for src,dst,readonly in [(base/'syscall-query.test','/syscall-query.test',True),(base/'worker-resource-probe','/resource-probe',True),(base/'encrypted-inputs','/fixture',True),(folder,'/output',False)]:cmd+=['--mount','type=bind,src='+str(src)+',dst='+dst+(',readonly' if readonly else '')]
 for key,val in {'ASSERVAT_SYSCALL_QUERY_RESOURCE_FIXTURE':'/fixture','ASSERVAT_SYSCALL_QUERY_RESOURCE_SHAPE':shape,'ASSERVAT_SYSCALL_QUERY_RESOURCE_MODE':mode,'ASSERVAT_SYSCALL_QUERY_RESOURCE_REPORT':'/output/component.json','GOMAXPROCS':'2','GOGC':'100'}.items():cmd+=['-e',key+'='+val]
 cmd += [image,'sh','-c',shell]
 report={'shape':shape,'mode':mode,'image':image,'command':cmd,'source_commit':inventory['commit'],'relevant_source_unchanged_before':True,'container_name':name}
 created=False;start=time.monotonic()
 try:
  created_read=run(cmd);report['create_exit']=created_read.returncode;report['create_stderr']=created_read.stderr
  if created_read.returncode:raise RuntimeError('docker create failed')
  created=True;report['container_id']=created_read.stdout.strip()
  print('START '+shape+'/'+mode+' '+report['container_id'],flush=True)
  try:
   started=run(['docker','start','-a',name],180);report['start_exit']=started.returncode;(folder/'docker-start.log').write_text(started.stdout+started.stderr)
  except subprocess.TimeoutExpired as e:
   report['timed_out']=True;stopped=run(['docker','stop','--time=5',name]);report['timeout_stop_exit']=stopped.returncode
  report['container_elapsed_seconds']=time.monotonic()-start
  inspected=run(['docker','inspect',name]);(folder/'docker-inspect.json').write_text(inspected.stdout)
  if inspected.returncode:raise RuntimeError('docker inspect failed')
  actual=json.loads(inspected.stdout)[0];report['state']=actual['State'];report['host_config']={k:actual['HostConfig'].get(k) for k in ('Memory','MemorySwap','NanoCpus','NetworkMode','CgroupnsMode','Privileged','ReadonlyRootfs','CapDrop')};report['user']=actual['Config']['User']
  for file in ('cgroup-before.json','cgroup-after.json','component.json'):
   p=folder/file
   if p.exists():report[file]=json.loads(p.read_text())
  for file in ('consumer-exit','probe-exit'):
   p=folder/file
   if p.exists():report[file]=int(p.read_text().strip())
  report['relevant_source_unchanged_after']=unchanged()
  for file in ('cgroup-before.json','cgroup-after.json'):
   probe=report.get(file)
   if probe:report[file+'_limits_match']=probe['memory_max']=={'value':256<<20,'unlimited':False} and probe['swap_max']=={'value':0,'unlimited':False} and probe['cpu_quota']=={'value':50000,'unlimited':False} and probe['cpu_period']==100000
  report['component_success']=report.get('consumer-exit')==0 and report.get('probe-exit')==0 and report.get('cgroup-before.json_limits_match') is True and report.get('cgroup-after.json_limits_match') is True and not report['state']['Running']
 finally:
  if created:
   removed=run(['docker','rm','-f',name]);report['cleanup_exit']=removed.returncode;report['cleanup_output']=removed.stdout+removed.stderr
  else:report['cleanup_exit']=None
  (folder/'run.json').write_text(json.dumps(report,indent=2)+'\n');reports.append(report)
  (base/'matrix.json').write_text(json.dumps(reports,indent=2)+'\n')
 print('END '+shape+'/'+mode+' exit='+str(report.get('consumer-exit'))+' cleanup='+str(report['cleanup_exit'])+' peak='+str(report.get('cgroup-after.json',{}).get('memory_peak')),flush=True)
 if not report.get('component_success') or report.get('cleanup_exit')!=0:break
left=run(['docker','ps','-a','--filter','label=asservat.packet-query-resource=owned','--format','{{.ID}}'])
(base/'remaining-containers.json').write_text(json.dumps({'exit':left.returncode,'ids':left.stdout.splitlines(),'stderr':left.stderr},indent=2)+'\n')
if len(reports)!=4 or any(not r.get('component_success') for r in reports) or left.returncode or left.stdout.strip():raise SystemExit(1)
