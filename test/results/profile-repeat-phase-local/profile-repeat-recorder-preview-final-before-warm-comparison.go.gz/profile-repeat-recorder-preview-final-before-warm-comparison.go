package capture

import (
	"context"
	"errors"
	"slices"
	"time"

	auditapp "asservat.local/asservat/internal/application/audit"
	identities "asservat.local/asservat/internal/application/identity"
	compiler "asservat.local/asservat/internal/application/planning"
	"asservat.local/asservat/internal/domain/artifact"
	"asservat.local/asservat/internal/domain/authorization"
	value "asservat.local/asservat/internal/domain/capture"
	"asservat.local/asservat/internal/domain/identity"
	"asservat.local/asservat/internal/domain/planning"
	"asservat.local/asservat/internal/domain/privacy"
	"asservat.local/asservat/internal/domain/targets"
)

// RecorderPreviewResult is a reviewed packet/syscall plan (ADR-243). Only
// Preview is persisted, so request_capture can refuse it with the same
// RecorderUnavailable blocker before acceptance; nothing is reserved.
type RecorderPreviewResult struct {
	CollectorImageDigest, ProjectionDigest artifact.Digest
	Preview                                value.ContextPreview
	Plan                                   planning.RecorderPlan
	Assessment                             planning.RecorderAssessment
	ValidUntil                             time.Time // Original metadata-delivery authority; never persisted.
	// Recordable marks an acceptable plan for an available node recorder
	// (ADR-248): request_capture can accept it.
	Recordable bool
}

const profileRepeatPreviewWindow = 8 * time.Second

// PreviewComposition compiles a one-component builtin capture profile
// composition for a currently authorized workload. It reads identity,
// recovery, the target, collection eligibility and retention exactly as a
// pod-status preview does, but no collector capability, storage binding or
// processing coverage: no recorder exists to use them. Authored composition
// errors are reported only after eligibility, so they disclose nothing about
// an unauthorized target. The libpcap compiler runs on the hub (S2).
func (s ContextInvestigation) PreviewComposition(ctx context.Context, source identities.CurrentIdentity, intent value.ContextIntent) (result RecorderPreviewResult, failure error) {
	return s.previewComposition(ctx, source, intent, nil)
}

func (s ContextInvestigation) PreviewCompositionRepeat(ctx context.Context, source identities.CurrentIdentity, intent value.ContextIntent, original authorization.Target) (RecorderPreviewResult, error) {
	if !authorization.UUID(original.ClusterID) || !identity.Text(original.NamespaceUID, 64) || !identity.Text(original.WorkloadUID, 64) {
		return RecorderPreviewResult{}, value.ErrInvalid
	}
	return s.previewComposition(ctx, source, intent, &original)
}
func (s ContextInvestigation) previewComposition(ctx context.Context, source identities.CurrentIdentity, intent value.ContextIntent, original *authorization.Target) (result RecorderPreviewResult, failure error) {
	defer func() { s.reportPreviewFailure(failure) }()
	var zero RecorderPreviewResult
	if !s.configured() || ctx == nil || source == nil || ctx.Err() != nil {
		return zero, previewFailure("configuration", value.ErrUnavailable)
	}
	if intent.Composition == nil || !intent.Valid() {
		return zero, previewFailure("composition/intent", value.ErrInvalid)
	}
	// Allocate the possible history-profile composition budget up front. The
	// ordinary classification phase and every non-profile path retain five
	// seconds; no consumed observation or caller deadline is extended.
	parent := ctx
	var profileRepeatCtx context.Context
	_, profileCapable := s.Recorders.(ProfileRecorders)
	if profileCapable && original != nil && intent.RepeatedFrom != nil && intent.RepeatedFrom.Valid(s.Now()) && len(intent.Composition.Components) == 1 {
		var finish context.CancelFunc
		profileRepeatCtx, finish = context.WithTimeout(parent, profileRepeatPreviewWindow)
		defer finish()
	}
	ctx, cancel := context.WithTimeout(parent, 5*time.Second)
	defer cancel()
	created := s.Now().UTC().Truncate(time.Microsecond)
	i, err := source.ResolveIdentity(ctx)
	if err != nil || !i.Valid(s.Now()) {
		return zero, previewFailure("identity", value.ErrDenied)
	}
	recovery, err := s.currentRecovery(ctx)
	if err != nil {
		return zero, previewFailure("recovery", err)
	}
	mark := time.Now()
	target, err := s.Targets.ResolveWorkload(ctx, intent.Target)
	auditapp.MarkStep(ctx, "p-target", mark)
	if err != nil {
		return zero, previewFailure("target", err)
	}
	if !target.Valid(s.Now()) {
		return zero, previewFailure("facts/target", value.ErrChanged)
	}
	var storageWait *contextStorageWait
	var ordinaryStorageUntil time.Time
	if original != nil && s.Recorders != nil && target.ExecutionClass == artifact.ContextAPIExecution && len(intent.Composition.Components) == 1 &&
		original.ClusterID == target.Request.ClusterID && original.NamespaceUID == target.Request.Namespace.UID &&
		original.WorkloadUID == target.Request.Workload.UID && (original.PodUID == "" || original.PodUID == target.Request.PodUID) {
		// Reuse this repeat's one readiness owner while current catalog and
		// recorder observations block. It grants no storage authority; final
		// consumption joins it and reads the binding independently.
		s.reviewTarget(ctx, source, i.Principal, target)
		until := identity.Earlier(identity.Earlier(i.ValidUntil, recovery.FreshUntil), target.FreshUntil)
		if intent.RepeatedFrom != nil {
			until = identity.Earlier(until, intent.RepeatedFrom.ExpiresAt)
		}
		ordinaryStorageUntil = until
		hint := ctx
		if profileRepeatCtx != nil {
			// Initial recovery/target facts authorize only the current review.
			// The hint grants no authority and retains neither observation for
			// the final plan. Fresh facts are independently acquired below.
			if !recovery.Valid(s.Now()) || !target.Valid(s.Now()) || ctx.Err() != nil {
				return zero, previewFailure("recovery", value.ErrUnavailable)
			}
			hint, until = profileRepeatCtx, identity.Earlier(i.ValidUntil, intent.RepeatedFrom.ExpiresAt)
		}
		storageWait = s.beginStorageWait(hint, target, until, value.ContextStorageSelection{})
		defer storageWait.close()
	}
	mark = time.Now()
	composition, err := s.withCatalogProfiles(ctx, intent.Composition, target)
	auditapp.MarkStep(ctx, "p-profiles", mark)
	if err != nil {
		return zero, previewFailure("profiles", err)
	}
	intent.Composition = composition
	if original != nil && (original.ClusterID != target.Request.ClusterID || original.NamespaceUID != target.Request.Namespace.UID || original.WorkloadUID != target.Request.Workload.UID || (original.PodUID != "" && target.Request.PodUID != original.PodUID)) {
		eligible := s.Eligibility.ContextEligibilityCurrent(ctx, source, target.Target())
		if !eligible.Eligible {
			return zero, value.ErrDenied
		}
		return zero, value.ErrTargetReplaced
	}
	if len(intent.Composition.Components) > 1 && target.ExecutionClass == artifact.ContextAPIExecution && s.Recorders != nil {
		// ADR-276: a manual multi-profile composition is a reviewed group.
		r, err := s.previewCompositionGroup(ctx, source, intent, i, recovery, target, created)
		if !errors.Is(err, errRecordingNotAcceptable) && !errors.Is(err, value.ErrRecorderUnavailable) {
			return r, err
		}
	}
	var available bool
	if profileRepeatCtx != nil && storageWait != nil && profileRecorderInput(intent) {
		// Readiness is scheduling, not retained target/recovery authority.
		// Join the same hint before the existing complete recorder resolution;
		// its fresh Pod/namespace/workload facts must match the original pin.
		ctx = profileRepeatCtx
		select {
		case <-storageWait.done:
		case <-ctx.Done():
			return zero, previewFailure("facts/readiness", ctx.Err())
		}
		if !intent.RepeatedFrom.Valid(s.Now()) {
			return zero, previewFailure("history", value.ErrSettingsUnavailable)
		}
		if _, err = s.currentIdentity(ctx, source, i.Principal, i.ValidUntil); err != nil {
			return zero, previewFailure("identity", err)
		}
		freshRecovery, e := s.currentRecovery(ctx)
		if e != nil || freshRecovery.InstallationID != recovery.InstallationID || freshRecovery.IssuerEpoch != recovery.IssuerEpoch || freshRecovery.Revision != recovery.Revision {
			return zero, previewFailure("recovery", value.ErrChanged)
		}
		recovery = freshRecovery
		var finish context.CancelFunc
		ctx, finish = context.WithDeadline(ctx, recovery.FreshUntil)
		defer finish()
		storageWait.until = identity.Earlier(storageWait.until, recovery.FreshUntil)
		profiles, ok := s.Recorders.(ProfileRecorders)
		if !ok {
			return zero, previewFailure("recorder", value.ErrRecorderUnavailable)
		}
		mark = time.Now()
		fresh, e := profiles.ResolveProfileRecorder(ctx, target.Request)
		auditapp.MarkStep(ctx, "p-recorder", mark)
		if e == nil && (ctx.Err() != nil || !fresh.Valid(s.Now()) || fresh.Request != target.Request || fresh.Pin != target.Pin) {
			e = targets.ErrChanged
		}
		if e != nil && !errors.Is(e, targets.ErrUnsupported) {
			return zero, previewFailure("recorder", e)
		}
		available = e == nil
		if available {
			target = fresh
		}
	} else {
		if storageWait != nil {
			storageWait.until = ordinaryStorageUntil
		}
		available, err = s.packetRecorderAvailable(ctx, intent, target)
	}
	if err != nil {
		return zero, previewFailure("recorder", err)
	}
	if available {
		r, err := s.previewRecording(ctx, source, intent, i, recovery, target, created, storageWait)
		if !errors.Is(err, errRecordingNotAcceptable) {
			return r, err
		}
	}
	t := target.Target()
	eligibility := s.Eligibility.ContextEligibilityCurrent(ctx, source, t)
	if !eligibility.Eligible || eligibility.Target != t || eligibility.Principal != i.Principal || eligibility.VerifiedIdentity.Principal != i.Principal || !eligibility.VerifiedIdentity.Valid(s.Now()) || !s.Now().Before(eligibility.ValidUntil) {
		return zero, previewFailure(previewEligibilityFailure(eligibility.Reason), value.ErrDenied)
	}
	// Authored errors only after current eligibility on the target.
	evidence, err := compiler.RecorderEvidenceType(*intent.Composition)
	if err != nil {
		return zero, previewFailure("composition", err)
	}
	r, err := s.Retention.Resolve(ctx, privacy.Input{Target: t, PrivacyClass: "potentialPersonalData", EvidenceType: evidence, RequestedSeconds: intent.RequestedSeconds, AnchorAt: created})
	if err != nil {
		return zero, previewFailure("facts/retention/"+retentionFailure(err), err)
	}
	current := func(now time.Time) bool {
		p := r.Proof
		return target.Valid(now) && p.Valid(now) && p.Matches(s.RootID, t.ClusterID, t.NamespaceUID, t.WorkloadUID, t.PodUID) && p.Policy == r.PolicyRevision && !r.ValidUntil.After(p.ValidUntil) && now.Before(r.ValidUntil) && now.Before(eligibility.ValidUntil) && eligibility.VerifiedIdentity.Valid(now) && recovery.Valid(now)
	}
	if !current(s.Now()) || ctx.Err() != nil {
		return zero, previewFailure("facts/current", value.ErrChanged)
	}
	p := value.ContextPreview{ID: s.NewID(), RootID: s.RootID, InstallationID: s.InstallationID, IssuerEpoch: recovery.IssuerEpoch, CaptureID: s.NewID(), CaseID: s.NewID(), OccurrenceID: s.NewID(), ArtifactID: s.NewID(), AttemptID: s.NewID(), Actor: i.Principal, Intent: intent, Target: target.Request, Pin: target.Pin, Retention: retentionReview(r), Audience: slices.Clone(eligibility.DefaultAudience), CreatedAt: created, Deadline: created.Add(s.Lifetime)}
	p.Intent.Composition = intent.Composition.Clone()
	p.ExecutionClass = target.ExecutionClass
	if intent.RepeatedFrom != nil {
		p.Deadline = identity.Earlier(p.Deadline, intent.RepeatedFrom.ExpiresAt)
	}
	p.AssessmentID, p.AssessmentRulesDigest = s.NewID(), compiler.RecorderAssessmentRulesDigest()
	required, err := s.requireRecordingApproval(ctx, source, i.Principal)
	if err != nil {
		return zero, previewFailure("approvals", err)
	}
	mark = time.Now()
	plan, err := s.compileRecorderPeers(ctx, planning.RecorderInput{CaptureID: p.CaptureID, Executor: p.Actor, Target: target, Composition: *intent.Composition, Retention: r, Deadline: p.Deadline, RequireApproval: required})
	auditapp.MarkStep(ctx, "p-compile", mark)
	if err != nil {
		return zero, previewFailure("compile", err)
	}
	p.CanonicalScope, p.ScopeDigest = slices.Clone(plan.CanonicalScope), plan.ScopeDigest
	p.AssessmentRulesDigest = compiler.RecorderAssessmentRulesFor(plan.Actions)
	assessment, err := compiler.AssessRecorder(plan, p.AssessmentID, s.Now())
	if err != nil {
		return zero, previewFailure("assessment", err)
	}
	if !ValidContextPreview(p) || !p.Current(s.Now()) {
		return zero, previewFailure("blueprint", value.ErrInvalid)
	}
	if _, err = s.currentIdentity(ctx, source, i.Principal, i.ValidUntil); err != nil || !current(s.Now()) {
		return zero, previewFailure("before-store/current", value.ErrChanged)
	}
	mark = time.Now()
	err = s.Previews.CreateContextPreview(ctx, p.Clone())
	auditapp.MarkStep(ctx, "p-store", mark)
	if err != nil {
		return zero, previewFailure("store", err)
	}
	final := s.Eligibility.ContextEligibilityCurrent(ctx, source, t)
	if !final.Eligible || final.Target != t || final.Principal != i.Principal || !final.VerifiedIdentity.Valid(s.Now()) || !i.Valid(s.Now()) || !slices.Equal(final.DefaultAudience, p.Audience) || !s.Now().Before(final.ValidUntil) || !current(s.Now()) || ctx.Err() != nil || s.Now().Before(created) {
		return zero, previewFailure("after-store/current", value.ErrChanged)
	}
	until := identity.Earlier(i.ValidUntil, recovery.FreshUntil)
	for _, bound := range []time.Time{final.ValidUntil, final.VerifiedIdentity.ValidUntil, eligibility.ValidUntil, eligibility.VerifiedIdentity.ValidUntil, assessment.ValidUntil, plan.ValidUntil} {
		until = identity.Earlier(until, bound)
	}
	if !s.Now().Before(until) || ctx.Err() != nil {
		return zero, previewFailure("response/current", value.ErrUnavailable)
	}
	return RecorderPreviewResult{Preview: p.Clone(), Plan: plan, Assessment: assessment, ValidUntil: until}, nil
}
