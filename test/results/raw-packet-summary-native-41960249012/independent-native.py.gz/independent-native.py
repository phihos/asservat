import struct, ipaddress, collections, hashlib, pathlib, json
base=pathlib.Path('/home/phil/.cache/asservat-build/raw-packet-summary/native41960249012-originals')
b=(base/'manual-raw.pcapng').read_bytes(); off=0; blocks=[]; interfaces=[]; rows=collections.Counter(); captures=collections.Counter(); wires=collections.Counter(); unclassified=0; payload_beyond134=0; actual_payload_frames=0; marker_frames=0; stats=[]; stamps=[]
def opts(buf):
 out=[]; i=0
 while i<len(buf):
  assert len(buf)-i>=4
  c,n=struct.unpack_from('<HH',buf,i); i+=4
  assert i+n<=len(buf)
  v=buf[i:i+n]; i+=(n+3)&~3
  if c==0:
   assert n==0 and i==len(buf)
   break
  out.append((c,v))
 assert i==len(buf)
 return out
while off<len(b):
 assert len(b)-off>=12
 t,n=struct.unpack_from('<II',b,off); assert n>=12 and n%4==0 and off+n<=len(b) and struct.unpack_from('<I',b,off+n-4)[0]==n
 body=b[off+8:off+n-4]; blocks.append(t)
 if t==0x0a0d0d0a:
  assert off==0 and struct.unpack_from('<I',body)[0]==0x1a2b3c4d
  opts(body[16:])
 elif t==1:
  link,res,snap=struct.unpack_from('<HHI',body); assert link==1 and res==0 and 0<snap<=200
  o=opts(body[8:]); resolution=next((v[0] for c,v in o if c==9),6)
  interfaces.append({'linktype':link,'snaplen':snap,'timestamp_resolution':resolution})
 elif t==6:
  iface,hi,lo,cap,wire=struct.unpack_from('<IIIII',body); assert iface<len(interfaces) and 0<cap<=wire and cap<=interfaces[iface]['snaplen']
  frame=body[20:20+cap]; assert len(frame)==cap; opts(body[20+((cap+3)&~3):]); captures[cap]+=1; wires[wire]+=1; stamps.append((hi<<32)|lo)
  payload_beyond134+=cap>134; marker_frames+=b'synthetic-approved-recording' in frame
  et=struct.unpack_from('!H',frame,12)[0] if len(frame)>=14 else 0
  if et==0x0800 and len(frame)>=34:
   assert frame[14]>>4==4
   ih=(frame[14]&15)*4; assert ih>=20 and not(struct.unpack_from('!H',frame,20)[0]&0x3fff)
   proto=frame[23]; src=str(ipaddress.ip_address(frame[26:30])); dst=str(ipaddress.ip_address(frame[30:34])); pos=14+ih
  elif et==0x86dd and len(frame)>=54:
   assert frame[14]>>4==6
   proto=frame[20]; src=str(ipaddress.ip_address(frame[22:38])); dst=str(ipaddress.ip_address(frame[38:54])); pos=54
  else:
   unclassified+=1; off+=n; continue
  if proto==6 and len(frame)>=pos+20:
   th=(frame[pos+12]>>4)*4; assert th>=20
   if len(frame)<pos+th:unclassified+=1;off+=n;continue
   sp,dp=struct.unpack_from('!HH',frame,pos); src=f'{src}:{sp}';dst=f'{dst}:{dp}'; name='TCP'; assert cap<=200
   actual_payload_frames+=len(frame)>pos+th
  elif proto==17 and len(frame)>=pos+8:
   sp,dp=struct.unpack_from('!HH',frame,pos);src=f'{src}:{sp}';dst=f'{dst}:{dp}';name='UDP';assert cap<=96
   actual_payload_frames+=len(frame)>pos+8
  elif proto in (1,58) and len(frame)>=pos+(8 if proto==1 else 4):name='ICMPv4' if proto==1 else 'ICMPv6';assert cap<=96
  else:
   unclassified+=1; off+=n; continue
  rows[name,src,dst]+=1
 elif t==5:
  iface,hi,lo=struct.unpack_from('<III',body);o=opts(body[12:]);d={c:struct.unpack('<Q',v)[0] for c,v in o if c in (4,5,6,7,8) and len(v)==8};stats.append({'interface':iface,'counters_by_option_code':d})
 else:raise AssertionError('unexpected block')
 off+=n
assert off==len(b) and collections.Counter(blocks)=={0x0a0d0d0a:1,1:1,6:54,5:1}
assert sum(rows.values())+unclassified==54
out={'native':{'file':'manual-raw.pcapng','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'independent_parser':'Python standard-library only; block/option/footer/EOF, Ethernet/IP/TCP numeric headers; does not invoke repository packet parser or tshark','interfaces':interfaces,'block_counts':dict(collections.Counter(blocks)),'saved_records':54,'classified_records':sum(rows.values()),'unclassified_records':unclassified,'directional_conversations':[{'protocol':p,'source':s,'destination':d,'packets':n} for (p,s,d),n in sorted(rows.items(),key=lambda x:(-x[1],x[0]))],'captured_length_histogram':dict(sorted(captures.items())),'wire_length_histogram':dict(sorted(wires.items())),'frames_beyond134_bytes':payload_beyond134,'frames_with_transport_payload':actual_payload_frames,'frames_with_native_marker':marker_frames,'native_marker_occurrences':b.count(b'synthetic-approved-recording'),'statistics':stats,'timestamp_first':stamps[0],'timestamp_last':stamps[-1],'complete_structural_eof':True}
p=pathlib.Path('/home/phil/.cache/asservat-build/raw-packet-summary/native41960249012-audit/independent-native.json');p.write_text(json.dumps(out,indent=2)+'\n');print(p.read_text())
