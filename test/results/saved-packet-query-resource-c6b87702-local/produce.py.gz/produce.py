import subprocess,os,time,json,signal,hashlib
from pathlib import Path
base=Path(__file__).parent
source=json.loads((base/'source-before.json').read_text())
fixture=base/'encrypted-inputs';fixture.mkdir(mode=0o700,exist_ok=True)
env=os.environ.copy()
for key in ('GOMEMLIMIT','ASSERVAT_PACKET_QUERY_FIXTURE','ASSERVAT_PACKET_QUERY_SHAPE','ASSERVAT_PACKET_QUERY_MODE','ASSERVAT_PACKET_QUERY_REPORT'):env.pop(key,None)
env.update({'GOMAXPROCS':'2','GOGC':'100','ASSERVAT_PACKET_QUERY_GENERATE':str(fixture)})
cmd=[str(base/'packet-query.test'),'-test.run=^TestPacketQueryEncryptedProcess$','-test.v','-test.timeout=3m']
start=time.monotonic();timeout=False
with (base/'producer.log').open('wb') as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 while True:
  pid,status,usage=os.wait4(p.pid,os.WNOHANG)
  if pid:break
  if time.monotonic()-start>180:
   timeout=True;p.terminate()
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:p.kill()
   # This path is a failed setup, not a producer resource measurement.
   status=0;usage=None;break
  time.sleep(.025)
 if usage is not None:p.returncode=os.waitstatus_to_exitcode(status)
report={'command':cmd,'env':{k:env.get(k) for k in ('GOMAXPROCS','GOGC','GOMEMLIMIT','ASSERVAT_PACKET_QUERY_GENERATE')},'source':source,'exit':p.returncode,'timedOut':timeout,'elapsed_seconds':time.monotonic()-start,'peak_rss_kib':usage.ru_maxrss if usage else None,'user_cpu_seconds':usage.ru_utime if usage else None,'system_cpu_seconds':usage.ru_stime if usage else None,'scope':'Separate host producer outside all consumer cgroups; no consumer or Docker execution.'}
if p.returncode==0 and not timeout:
 report['fixture']=json.loads((fixture/'probe.json').read_text())
 for item in report['fixture']['Inputs']:
  for name,want in item['Files'].items():
   path=fixture/item['Shape']/name
   if hashlib.sha256(path.read_bytes()).hexdigest()!=want:raise RuntimeError('producer fixture digest mismatch')
   path.chmod(0o444)
 (fixture/'probe.json').chmod(0o444)
(base/'producer-resource.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('source','fixture')}))
raise SystemExit(p.returncode if p.returncode else int(timeout))
