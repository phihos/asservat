import pathlib,json,hashlib,subprocess,io,struct,datetime
base=pathlib.Path(__file__).parent;root=pathlib.Path('/home/phil/Projekte/asservat-saved-packet-query');prior=base.with_name('saved-packet-query-resource-final-9bf84fcc')
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=load(base/'source-before.json');inv=load(base/'relevant-sources.json');files=inv['files'];assert len(files)==1812
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head==inv['commit']=='c6b877026e416e3a457902bfd296282d9a8c4096'
proc=subprocess.run(['git','cat-file','--batch'],cwd=root,input=''.join(head+':'+p+'\n' for p in files).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);stream=io.BytesIO(proc.stdout)
for p,want in files.items():
 h=stream.readline().decode().split();assert len(h)==3 and h[1]=='blob';raw=stream.read(int(h[2]));assert stream.read(1)==b'\n';assert hashlib.sha256(raw).hexdigest()==want and sha(root/p)==want,p
assert not stream.read();assert sha(base/'packet-query.test')==source['binary_sha256'];assert sha(base/'worker-resource-probe')==source['probe_sha256']=='7ec2674deffe5f75908c851bb1dc9e22d491a3a6e3dfc8e80475f840edbfcfcb'
status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True);after={**source,'head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'gitStatus':status,'mismatches':[]};(base/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
old=load(prior/'relevant-sources.json');changes=[p for p in files if old['files'].get(p)!=files[p]]
producer=load(base/'producer-resource.json');assert producer['exit']==0 and not producer['timedOut'];fixture=load(base/'encrypted-inputs/probe.json');assert fixture['BinarySHA256']==source['binary_sha256'];inputs=[]
for v in fixture['Inputs']:
 folder=base/'encrypted-inputs'/v['Shape']
 for p,want in v['Files'].items():assert sha(folder/p)==want,(v['Shape'],p)
 raw=(folder/'native.pcapng').read_bytes();assert len(raw)==v['NativeBytes']==8388608;at=0;count=0;captured=0;wires=set()
 while at<len(raw):
  typ,n=struct.unpack_from('<II',raw,at);assert n>=12 and n%4==0 and at+n<=len(raw) and struct.unpack_from('<I',raw,at+n-4)[0]==n
  if typ==6:
   cap,wire=struct.unpack_from('<II',raw,at+20);assert cap<=wire;count+=1;captured+=cap;wires.add(wire)
  at+=n
 assert at==len(raw) and count==v['Packets'] and captured==v['CapturedBytes'] and len(wires)==v['DistinctWireLengths']
 inputs.append({'shape':v['Shape'],'nativeBytes':len(raw),'nativeSHA256':sha(folder/'native.pcapng'),'packets':count,'capturedBytes':captured,'distinctWireLengths':len(wires),'lateWinningRecords':100,'allPreparedFilesSHA256Match':True})
runs=[]
for name in ['payload-output-complete','tiny-prefix-wire-cache-complete','payload-output-cancel','payload-output-source-error']:
 folder=base/name;r=load(folder/'run.json');c=load(folder/'component.json');d=load(folder/'docker-inspect.json')[0]
 assert r['create_exit']==r['start_exit']==r['consumer-exit']==r['probe-exit']==r['state']['ExitCode']==r['cleanup_exit']==0
 assert int((folder/'consumer-exit').read_text())==int((folder/'probe-exit').read_text())==0
 assert d['State']==r['state'] and not d['State']['Running'] and not d['State']['OOMKilled'] and d['Config']['User']==r['user']=='1000:1000'
 assert d['Image']==r['image']=='sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e'
 assert c==r['component.json'] and c['binary_sha256']==source['binary_sha256'] and c['synthetic_unwraps']==3 and c['receiver_joined'] and c['conversation_bound_ns']==20000000000 and c['program_instructions']==256 and c['selected_unique_fields']==16 and c['frame_prefix_bytes']==64
 assert c['gogc']=='100' and c['gomaxprocs']==2 and c['gomemlimit']==''
 hc=r['host_config'];assert hc['Memory']==hc['MemorySwap']==268435456 and hc['NanoCpus']==500000000 and hc['NetworkMode']=='none' and not hc['Privileged'] and hc['ReadonlyRootfs'] and hc['CapDrop']==['ALL']
 for k,v in hc.items():assert d['HostConfig'][k]==v
 for p in ['cgroup-before.json','cgroup-after.json']:
  g=load(folder/p);assert g==r[p] and g['binary_sha256']==source['probe_sha256'] and g['memory_max']=={'value':268435456,'unlimited':False} and g['swap_max']=={'value':0,'unlimited':False} and g['swap_current']==0 and g['cpu_quota']=={'value':50000,'unlimited':False} and g['cpu_period']==100000
  assert all(g['memory_events'].get(k,0)==0 for k in ['max','oom','oom_kill','oom_group_kill'])
 if c['mode']=='complete':assert c['result_valid'] and not c['read_failed'] and c['expected_shape_match'] and c['rows']>0
 else:assert not c['result_valid'] and c['read_failed'] and c['rows']==0
 assert '--- PASS: TestPacketQueryEncryptedProcess' in (folder/'consumer.log').read_text();before=r['cgroup-before.json'];aftercg=r['cgroup-after.json'];a=datetime.datetime.fromisoformat(aftercg['observed_at'].replace('Z','+00:00'));b=datetime.datetime.fromisoformat(before['observed_at'].replace('Z','+00:00'))
 runs.append({'shape':c['shape'],'mode':c['mode'],'consumerExit':0,'probeExit':0,'containerExit':0,'cleanupExit':0,'peakMemoryBytes':aftercg['memory_peak'],'processPeakRSSKiB':c['process_peak_rss_kib'],'syntheticKeyRoles':3,'joined':True,'resultValid':c['result_valid'],'readFailed':c['read_failed'],'rows':c['rows'],'scannedPackets':c['logical_scanned_packets'],'logicalScannedBytes':c['logical_scanned_bytes'],'operationElapsedSeconds':c['operation_elapsed_ns']/1e9,'operationUserCPUSeconds':c['operation_user_cpu_ns']/1e9,'operationSystemCPUSeconds':c['operation_system_cpu_ns']/1e9,'wholeCgroupWallSeconds':(a-b).total_seconds(),'cgroupCPUUsageDeltaSeconds':(aftercg['cpu_stat']['usage_usec']-before['cpu_stat']['usage_usec'])/1e6,'CPUPeriodsDelta':aftercg['cpu_stat']['nr_periods']-before['cpu_stat']['nr_periods'],'CPUThrottledPeriodsDelta':aftercg['cpu_stat']['nr_throttled']-before['cpu_stat']['nr_throttled'],'cancelJoinNanos':c['cancel_join_ns'],'observedBefore':before['observed_at'],'observedAfter':aftercg['observed_at']})
left=subprocess.run(['docker','ps','-a','--filter','label=asservat.packet-query-resource=owned','--format','{{.ID}}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);assert not left.stdout.strip();assert load(base/'remaining-containers.json')['ids']==[]
(base/'cleanup-readback.json').write_text(json.dumps({'command':['docker','ps','-a','--filter','label=asservat.packet-query-resource=owned','--format','{{.ID}}'],'exit':left.returncode,'ids':left.stdout.decode().splitlines(),'stderr':left.stderr.decode()},indent=2)+'\n')
assert all(x['exit']==0 for x in load(base/'build-commands.json')['commands'])
report={'format':'packet-query-final-resource-audit/v1','verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'PASS scoped functional/join/memory component; CPU quota configuration ONLY','cache':str(base),'compiledSourceCommit':head,'finalRepositoryHead':head,'sourceFileCount':1812,'GitBlobComparisons':1812,'GitCatFileBatchCalls':1,'allGitBlobSHA256MatchCommit':True,'allCurrentDependencySourceSHA256Match':True,'binarySHA256':source['binary_sha256'],'probeSHA256':source['probe_sha256'],'priorMeasuredSourceCommit':old['commit'],'changedCompiledInputsFromPrior':changes,'priorBinarySHA256':load(prior/'source-before.json')['binary_sha256'],'producer':{'exit':0,'elapsedSeconds':producer['elapsed_seconds'],'peakRSSKiB':producer['peak_rss_kib'],'scope':'Fresh separate producer outside all consumer cgroups'},'inputs':inputs,'runs':runs,'ownedContainersRemaining':[],'originalOperationWindowSeconds':20,'limits':{'memoryBytes':268435456,'swapBytes':0,'configuredMillicores':500},'CPUQualification':'Configured cpu.max50000/100000 and DockerNanoCpus500000000 verified before/after only. Short wall/CPU/period/throttling counters do NOT establish effective or sustained500m enforcement/throughput. No such qualification claimed.','memoryQualification':'Recorded cgroup peaks and process MaxRSS are separate observations, not universal maxima or allshape combinations. Allfourruns memory.max256MiB/swap.max0/current0/no max/OOMevents.','setupFailuresThisRefresh':[],'scopeExclusions':'Actual approvedreceiver/outerNativeReader/GoVM256/fullcanonical+framedEOF/encryptedTLSsource+3synthetickeyroles/localproviderallocations included. No hub/libpcap compilation, SQL/currenthuman/grant authority, realKMS, nativeowner/publictransport/bootstrap/enrollment/installedmaximuminput or sustainedCPU qualification. Four named freshcases only, no consumersrerun/source edits.'}
p=base/'final-audit.json';p.write_text(json.dumps(report,indent=2)+'\n');print(p,p.stat().st_size,sha(p));print(json.dumps({'head':head,'sourceCount':1812,'changedFrom9bf':changes,'peaks':[r['peakMemoryBytes'] for r in runs],'cpuAndWall':[[r['cgroupCPUUsageDeltaSeconds'],r['wholeCgroupWallSeconds'],r['CPUPeriodsDelta']] for r in runs],'hashes':[r['nativeSHA256'] for r in inputs]}))
