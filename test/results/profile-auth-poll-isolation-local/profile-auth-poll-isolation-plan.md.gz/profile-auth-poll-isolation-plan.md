# Isolate private profile authorization failures within node polls

Observed: PR164 review identified a deterministic batch failure: one unavailable
private authorization makes the whole poll fail, preventing unrelated original
work and cancellations from reaching the node. No production frequency measured.
The review's prefix truncation suggestion still blocks a failing first item.

Use one receive-only optional authorizationUnavailable bit, restricted to an
original authorization-required profile with no material. Preserve every original
work ID, sequence, target and deadline. The node reuses its existing one-use spent
record and zero-byte ProfileUnavailable upload; it opens no profile socket,
reserves no frozen native bytes, changes no funding and retries no acquisition.
Private fields never enter retained public Work, SQL, approval or evidence.
Request cancellation and unauthenticated processes continue to abort the poll.

Complexity review:
1. Deterministic regression; frequency unknown, harmful to unrelated work/cancel.
2. No accepted risk is reopened; no authority/funding guarantee is weakened.
3. Normal batched node work benefits; unavailable credential is the failure case.
4. Reuse existing nodeProfiles busy-refusal/spent/zero-byte result path.
5. Zero new privileges, credentials, roots, RBAC or network destinations.
6. Zero new product outcomes; one transient transport representation of existing ProfileUnavailable.
7. Zero settings, watches, loops or fallback controls.
8. Zero new dependencies; existing TLS poll/status/profile-upload transports.
9. At most16 items processed per poll; one bounded zero-byte terminal upload per
   failed original work, existing receipt/status, no file/API credential reads.
10. Unmerged feature; existing connector-first/capability rollout applies. Tests
    must retain ordinary HTTP/TLS/auth-success encoding and strict failure forms.
11. Truncation still blocks later cancellations; silently skipping drops original
    work/receipt responsibility. A typed per-item refusal preserves that contract.

Proof required: real mTLS batch regression RED then GREEN, original ordered work
and cancellation delivered, receipts advance; malformed refusal combinations
rejected; original identity/deadline/replay checks, zero acquisition/header/frozen
reservation and exactly one failure result. Independent review before gates/push;
no native dispatch until findings resolved. Full spec and installed auth remain open.
