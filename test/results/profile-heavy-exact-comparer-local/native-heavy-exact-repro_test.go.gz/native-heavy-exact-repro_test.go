package diagnostics

import (
	analysis "asservat.local/asservat/internal/domain/analysis"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"os"
	"testing"
	"time"
)

// Temporary local reproduction on the exact downloaded synthetic native bytes.
// This is not an encrypted-source, SQL/KMS/transport or installed worker proof.
func TestNativeHeavyExactB5Comparer(t *testing.T) {
	base := "/home/phil/.cache/asservat-build/profile-heavy-native-41834018171/native-continuation-profile-comparison-heavy-1/"
	paths := [2]string{base + "manual-profile-5c231a44-449e-4e10-aab9-a4c87ee2bae6.pb.gz", base + "manual-profile-49ccf6e7-9934-428f-b036-0e74f9d6ab4e.pb.gz"}
	var readers [2]*os.File
	for n, path := range paths {
		f, e := os.Open(path)
		if e != nil {
			t.Fatal(e)
		}
		defer f.Close()
		h := sha256.New()
		size, e := io.Copy(h, f)
		if e != nil {
			t.Fatal(e)
		}
		t.Logf("source ordinal=%d bytes=%d sha256=%s", n, size, hex.EncodeToString(h.Sum(nil)))
		if _, e = f.Seek(0, 0); e != nil {
			t.Fatal(e)
		}
		readers[n] = f
	}
	s, e := analysis.NormalizeProfileComparisonSelection("cpu", os.Getenv("ASSERVAT_REPRO_NORMALIZATION"), 20)
	if e != nil {
		t.Fatal(e)
	}
	facts := analysis.ProfileComparisonAcquisition{ProfileType: "cpu", Mode: "interval", ForceGC: false}
	ctx, cancel := context.WithTimeout(t.Context(), 20*time.Second)
	defer cancel()
	began := time.Now()
	out, err := ComparePprof(ctx, readers[0], facts, readers[1], facts, s)
	elapsed := time.Since(began)
	encoded, encodeErr := json.Marshal(out)
	t.Logf("normalization=%s error=%v valid=%t rows=%d baselineDuration=%v incidentDuration=%v elapsed=%s context=%v encodedBytes=%d encodeError=%v", s.Normalization, err, out.Valid(s), len(out.Rows), out.Baseline.DurationSeconds, out.Incident.DurationSeconds, elapsed, ctx.Err(), len(encoded), encodeErr)
	for _, side := range []analysis.ProfileComparisonFacts{out.Baseline, out.Incident} {
		if side.DurationSeconds != nil {
			t.Logf("native duration seconds=%.9f total=%d", *side.DurationSeconds, side.Total)
		}
	}
	if err != nil || !out.Valid(s) || len(out.Rows) != 20 || ctx.Err() != nil || encodeErr != nil {
		t.Fail()
	}
}
