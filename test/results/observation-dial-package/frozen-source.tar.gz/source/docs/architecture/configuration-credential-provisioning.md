# Configuration credential provisioning

The ADR-140 configuration bootstrap breaks the credential dependency cycle
without accepting fleet configuration or recovery. It consumes actual guarded
Kubernetes fleet/owner sources, native namespace/workload protection and the
original positive SQL activation. The complete installed public graph remains
unfinished and disabled.

## Source and effect order

`RunConfigurationRoleInstaller` reads a closed private deployment document and
fixed administrator/probe/SQL files. It constructs the native protection and
fleet/owner readers, `ConfigurationRoleSource`, the protected Secret root and
`ConfigurationRuntimeSQLRoles`. The private `configuration-role-install` command calls this implementation.
`BuildConfigurationRoleInstallerInput` generates the closed public input from
matching existing owner/reconciler documents and original retained object/claim
references; it confers no current authority. Creation and protection of the
installed continuation workload/input projection remain pending.

The first source proof brackets three actual negative enforcement proofs with
exact namespace/guard checks and canonical fleet/owner/live Deployment/account
reads before and after. Credential bootstrap accepts an exact inert Deployment
at zero desired replicas, or one desired reconciler plus one retained rollout
process. At zero replicas, the surge limit is still checked against the later
one-replica deployment; scaling cannot expose an unbacked allowance. This is
an installation phase, not readiness or permission to launch. Rechecks repeat the actual negative checks,
administrator identity, exact canonical sources/workload and before/after guard
versions. Matching object identities alone never proves unchanged enforcement.

The original operation deadline covers Claim, SQL lock acquisition, post-lock
current source read, role creation/readback, login verification and receipt
completion. Final read-only role verification and projection publication share
another explicit original operation. Operation-local reuse removes duplicated
full setup around passive GETs; it supplies no authority to another request.
Any changed/failed proof invalidates that slot. Close cancels and joins work.
UTC normalization preserves timestamp instants; it does not move deadlines.

SQL creation locks recovery then the installation, rereads the protected root
after waits, checks original claims/current sources, and consumes only a
positively acknowledged first claim. Exact lookup following an unknown result
cannot create, repair, grant, reset a password or adopt a pre-existing role.
OID, SCRAM login, provenance and direct/ambient privileges are checked. No
secrets or secret-payload digests enter SQL audit or safe diagnostics.

## Fixed role inventory

Each pool has `MaxConns=1`. Each configuration role has a cluster-wide connection
limit of three: two retained reconciler processes and one verifier. This bound
is separate from the partial public hub role allowance. Complete all-purpose
PostgreSQL budget validation remains an installed-provisioning prerequisite.

| Purpose | SQL role suffix | Projection | Effects |
| --- | --- | --- | --- |
| configuration-fleet | `_cfg_00` | `sql-fleet.json` | Fleet observation and restrictive source state; no activation/recovery writes |
| configuration-source | `_cfg_01` | `sql-configuration.json` | Pending owner configuration/source projection; no audit acknowledgement |
| configuration-audit | `_cfg_02` | `sql-audit.json` | Exact current owner-configuration receipt acknowledgement; no source acceptance or activation |

All three have bounded current-trust reads and lock privileges. The compiled
plan is authoritative for exact columns. In particular, lock privilege on an
immutable identity column does not permit lease, allocation or activation
mutation. The native SQL matrix must verify actual trigger/ACL behavior,
including PUBLIC, membership and ownership effects.

The original protected Secret is finite and mutable only through its closed
claim/receipt CAS transitions. The runtime projection is immutable, carries
`configuration-roles.json` and those three credential files, and is accepted
only after positive exact readback and original UID receipt. No audit HMAC or
artifact key is present. Existing initial installation credentials and retired
manager state are not reopened.

`NewProvisionedHubWorkerDeployment` verifies the original manifest, fixed SQL
names, current role OIDs/ACLs and one-connection pools before composing actual
reconciliation. `CurrentOwnerConfigurationAcknowledgements` locks recovery
before configuration, retains the current snapshot and shortest original bound
through COMMIT, and does not activate configuration. The legacy constructor and
command continue their prior behavior in this checkpoint.
`BuildProvisionedHubWorkerWorkload` reuses the existing inert Restricted
workload and exact RBAC, with SQL credentials and manifest mounted from the
installation-derived immutable role projection. Its separate provider Secret
contains only audit storage/wrapping credentials. No replicas are enabled by
the builder. The command switch
is a required subsequent integration hunk once projections are actually
produced; it is not a permanent fallback for installed public serving.

Installed ordering is exact inert Deployment, protected inputs and immutable
SQL projection, then an independently checked UID/resource-version CAS launch.
The source proof retains the complete original spec digest and resourceVersion,
so zero-to-one during an original claim is a source change and rejects that
operation. Claims and SQL role provenance keep their original inert spec digest.
A successful later launch therefore needs its own exact retained disposition
for read-only installer replay; it cannot reinterpret the running spec as the
original role claim or authorize another CREATE. The one-use launch component now implements that retained disposition. The
complete installed object/input handoff remains pending.

## Actual qualification boundary

The isolated path4 source passed six-package compile and five-package vet.
Selected original-deadline, joined-close and unchanged-object negative tests
passed. Its complete-path assertion failed because the test did not pass the
deadline it asserted; that failure is retained. Path5 changes only that test
to supply the exact original deadline and passes the full loopback API path.

At unchanged production 20 QPS/burst-20 and real time, the three Claim →
post-lock read → Complete operations took 4.551993804s, 4.550681374s and
4.551830073s, each with 118 HTTP requests and nine phase/purpose negative
probes. Final inventory → immutable projection took 4.650914493s, 120 requests
and nine probes. The API, enforcement responses and role receipts in this
measurement are synthetic; source clients, Secret CAS and cancellation are
real implementation code. The remaining headroom is small and does not prove
native installed availability.

Earlier failed checkpoints remain recorded: initial root setup exhausted
4.951955789s/149 requests; the first flattening exposed timestamp readback;
UTC normalization then exposed a complete-role 4.999557525s timeout. No passing
claim replaces those failures or extends the original five-second contract.

The native SQL/S3/OpenBao matrix passes fourteen selected cases, covering exact
grants, stale stored source freshness with fresh independent proof, negative
recovery/source state, post-lock source change, unknown claims and current audit
acknowledgement. It returns exit 0 with 1,488 unchanged source hashes and clean
teardown; exact results are in the [progress record](../implementation-progress.md).
Source/Secret facts are explicitly synthetic. Actual Kubernetes protection/Secret qualification,
combined provider path, installed command, restart/projection continuity and
public browser/MCP/capture/download journey remain required.

The reduced integration package excludes unfinished public HTTP/session/service
composition and preserves the existing command. Its extraction still needs an
integrated compile, repository contract/architecture gates and native tests;
the larger passing overlay is not proof those new integration steps passed.

The follow-up input/projection selection passed component races (bootstrap
1.122s, Kubernetes1.046s), affected compile and vet in immutable run65840.
Its reduced CLI/test-helper extraction requires integrated rechecking. These
checks did not run a protected installer Pod or actual generated projection
handoff; the installed command switch remains pending that qualification.

The inert-phase correction has a failing-before regression against desired=1.
The fixed predicate, original-rate inert claim/completion and mid-claim zero-to-one
rejection pass the focused race selection (43.075s package result); affected
compile and Kubernetes vet pass. Run87334 verified three payload/base files
and 1,372 dependency hashes unchanged. These checks use synthetic Kubernetes
enforcement and SQL receipts; they do not qualify the actual launch or replay.

## One-use launch and replay

After positive role receipts and the immutable SQL projection, the original
protected root may retain one exact launch claim. Its acknowledged first CAS
permits only the original Deployment UID/resource-version transition from zero
to one desired replica. The original spec, projection/configuration/provider
UIDs, current enforcement and five-second operation remain binding. An unknown
claim or workload update permits lookup only; no retry can create another launch.

A separate read-only SQL inventory verifies the exact retained transition while
preserving original inert role-claim provenance. The installer selects this
replay branch whenever a launch disposition exists. It cannot reopen role or
projection creation. The current source proof remains required after SQL locks
and before a result receipt. No receipt is readiness, recovery or public authority.

The integrated component passed its staged loopback TLS launch/replay/lost-reply,
enforcement-change and original-expiry races. Those fixtures supply synthetic
SQL receipts/provider objects. The subsequent native SQL matrix passes six actual
role/lock/recovery cases with synthetic Kubernetes facts; the separate native
Kubernetes matrix passes five actual guard/Secret/Deployment cases with synthetic
SQL/provider facts. Both preserve original provenance and uncertain outcomes.
Exact commands, earlier failures and clean source/teardown reports are in the
[progress record](../implementation-progress.md). Actual protected resource
production, guard handover and installed command qualification remain required;
the chart and public workflows stay disabled.

The separate owner identity projection also binds the original provider
endpoints and roots, complete current workload-guard pins and original resource
receipts. Its constructor rejects changed or omitted probe/lease/history fields;
projection and launch read the exact original Deployment and template/image
under the earliest original caller or snapshot deadline before claiming effects.
The native-qualified SQL role producer does not establish provider capability
provenance. The fresh nineteen-resource owner layout and installed process have
separate qualification requirements, recorded in the progress file.

## Public runtime projection operation

[ADR-148](../decisions/148-public-projection-enforcement.md) makes the public
runtime Secret publisher's five current boundaries explicit: before root read,
after root read before claim CAS, after acknowledged claim before CREATE,
after exact Secret/root readback before receipt CAS, and after receipt before
success. Only the first independently denied native enforcement observation is
reused, within the unchanged earliest caller, SQL verification, source, root and
five-second interval. Each boundary still reads complete current policy/binding
pins, namespace, actual administrator, accepted SQL source and exact original
worker journal/Deployment/account/Lease. Changed or unavailable reads permanently
fail that call, with no proof reacquisition.

The operation is private to one serialized Publish and borrows the existing
root cancellation/join lifetime. It adds no shared cache or refresher. Unknown
claim replies never permit CREATE; unknown CREATE permits exact lookup only;
an unknown receipt may already exist but cannot report success. A later
independent invocation obtains its own enforcement proof and remains lookup-only.
This is bounded enforcement freshness, not instantaneous revocation between API
requests. Native protected producer/SQL/API composition remains a separate gate.
