# Fresh provider-installed pair

[ADR-149](../decisions/149-fresh-provider-installed-pair.md) defines the original
worker2/owner2 selection. The installer chooses both before the first of the
nineteen resource claims. Neither a later file nor an observed provider response
can upgrade a legacy resource receipt.

C-21 owns the protected installation operation. The original native resource and
bridge objects produce the three separate configuration SQL roles and their
immutable projection. A finite `CompleteInputs` driver then binds the original
ServiceAccount and selected audit Secret, inspects the exact provider recipe and
publishes the worker's immutable input. An unknown create is followed only by
inspection of the original object. It cannot reopen creation or renew the root.

Provider inspection precedes SQL locking. Concrete operation handles preserve
the same native root, current source checks and the earliest original deadline
through SQL locks, the permitted effect and final checks. A shortened final
native observation also narrows the context used by subsequent SQL reads and
commit. Closure joins admitted operations. The launch and owner projection
components now have finite original-root phase drivers and joined-shutdown
tests; their actual installed composition remains a separate qualification.

The runtime profile uses standard Kubernetes authentication with two worker and
four owner token purposes. Explicit scoped storage credentials retain their
original Secret identities. Required versioned audit constructors reject missing
or null versions and select the acknowledged original version on read. The
[initial installer](../decisions/151-initial-audit-version-requirement.md) now
requires immutable audit versions under every recognized active input format.
Fresh bootstrap v4 binds preparation/installer v2 before effects, while historical
input bytes remain unchanged. Component tests reject absent/null versions without
fallback; native initial and independent restore qualification remain separate. Complete
physical-version accounting and independently verified retirement are release
requirements.

The [integration manifest](../../test/results/provider-pair-framing-integration.json)
records the component payloads and their preceding checks. The fresh native
fixture continues the actual pristine bootstrap chain with real provider
inspection, scoped storage behavior and SQL role production. Its test outcome
must be recorded independently in [implementation progress](../implementation-progress.md).
The [fresh bootstrap-to-input run](../../test/results/provider-pair-native-3/result.json)
passes against the actual Kubernetes/provider/SQL/storage services with all
original clients and deadlines retained. Both runtime Deployments remain at zero
replicas. Runtime selection remains disabled; an input receipt does not establish
a running service or a completed developer investigation.

The [original owner selection](../decisions/149-fresh-provider-installed-pair.md#original-owner-bootstrap-selection)
now allocates permission-root and logical peer names once through the retained
resource journal and a fixed immutable public ConfigMap. Generated owner inputs
require its original receipt and genuine current final proof. Projection checks
read that exact child before and after locks and at completion. Selection itself
creates no permission stream or peer authority. The [component report](../../test/results/owner-bootstrap-selection-integration.json)
covers bounded replay, unknown replies, substitution rejection and joined closure;
actual SQL4/owner startup and shared-client availability remain pending.
