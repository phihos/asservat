# Regional API context start

ADR-135 connects the existing hub `ContextAcceptedStart` port to the regional `APIContextRunner` over a retained connector-originated HTTP/2 exchange. This is a private first-profile component. It does not enable public collection or supply missing installer authority.

## Ownership and flow

`bootstrap.RegionalAPIContextStart` reads the exact accepted API work with current identity/recovery, checks the protected capability, reserves a cluster capture slot and signs only the existing reference. It has no collector, evidence-key or evidence-reader dependency. `contextstart.Router` attaches that request to a current standby on the same hub process. Historical request replay stays passive; explicit fresh-current continuation uses the original key/preview/capture and exact acknowledged SQL52 read.

`mtls.ContextStartClient` opens one fixed-path POST to a currently accepted owner route using process-owned connector client keys. One actual TLS1.3 socket is handed to Go's standard HTTP/2 transport. There is no redirect, compression, rewindable body or uncertain POST retry. `ContextStartIngress` verifies the actual TLS chain, current exact connector leaf/process/source and local hub owner. Independently supplied executor pins are checked against the Hello; Hello does not supply collection authority.

`contextstart.ServeRegional` waits passively for the first work frame under the original standby residency. Only after receipt does it acquire a fresh exact peer proof and verify the disjoint signed API work. `AuthenticatedAPIContextRunner` compares all signed references with actual accepted SQL/process/capability values before calling the existing runner. No key preparation follows an old or uncertain execution preparation. The regional result contains only a finite disposition, not ciphertext receipts, native bytes or raw errors. Publication still requires the separate existing verification/audit/catalog path.

The work type is `asservat-api-context-work+jws`, fixed Ed25519. Work binds the exact capture/attempt, human actor/client, target, scope/expectation/minimized-intent/budget digests, capability and projection, actual connector leaf and connector/API/hub process identities. Groups and scopes appear only in ephemeral authenticated identity answers. No public token/cookie is forwarded. A dedicated verify-only trust ConfigMap uses current recovery plus its own independent native enforcement proof. Existing node work bytes and trust purpose remain unchanged.

## Original bounds and resource ceilings

| Item | Bound |
| --- | --- |
| Standby residence | Original 30 seconds; no human authority |
| Setup, peer proof, work and identity authority | At most original 5 seconds; minimum of all contributing observations |
| Complete discovered owner set | 16; oversized/incomplete list is unavailable |
| Whole hub standby budget | At most 64, independently reserved per cluster |
| Whole hub capture budget | At most 16, independently reserved per cluster |
| Regional owner conversations | At most 16, one per exact owner/process |
| Work / signed work | 8 KiB canonical / 16 KiB JWS |
| Identity answer | 192 KiB canonical; no truncation or narrower identity limits |
| Whole exchange | 20 frames, 2 MiB, at most 8 sequential identity checks |
| Connector API settings | 16 KiB, at most 16 exact input references |

JSON encoding disables HTML escaping before canonicalization. Actual maximum-string encoding is tested, including quotes, backslashes and Unicode. The settings bound was corrected after the maximum legal 16-input test failed at 8 KiB. This changes only the new private settings format.

Work and independently current peer/trust observations may overlap without having identical ends. Verification takes their minimum; it does not reject a valid shorter proof or renew it. Every blocking read/sign/write retains that minimum. The stream owns a single bounded EOF reader, one queued frame and one decoder frame. Socket/pipe callbacks cancel and join before release. Stream termination cancels the same hub identity and regional runner contexts, including a blocked final identity resolution. A late positive backend result cannot authorize a reply after cancellation.

Standby and capture reservations count closing owners until joined completion. Each discovered owner has an independent thirty-second conversation with at least one second before a fresh empty standby. A retry never carries a capture, signed work or human identity from a prior connection. SQL52/ADR134 determine whether an explicit current continuation can proceed; transport failure is not proof of non-admission or no effect.

## Protected connector API process

`ConnectorAPIExecutionProtection` composes the concrete connector attester, owned credentials, namespace guard and separate immutable API settings. It checks current online Pod-bound TokenReview, SSR account/Pod identity, live Deployment/ReplicaSet/Pod chain, current original CSR/leaf registration and all exact settings/input pins. A new independent API process epoch is generated once; it is not the connector epoch and cannot follow a replacement connector process silently.

One concrete protection instance coalesces a single positively completed process proof. Reuse retains the original observation start and earliest end, including the original TokenReview and independent admission-denial intervals. It performs current process credential/source/registration, SSR account/Pod identity, namespace/account, exact guard policy/binding, immutable settings, full workload digest and approved input metadata checks before returning. These later reads can shorten the interval; they cannot create a new denial proof or renew it. An error or known change invalidates the snapshot and any in-flight publication generation. A cancelled waiter cannot detach the original producer; cancellation, expiry or invalidation prevents a late positive producer from entering the cache. There is no background refresh or general Kubernetes client cache.

After expiry, a new independent invocation may perform the full proof again under its own original caller bound. Existing preparation, binding and request deadlines remain fixed. The optional per-frame observation lease and source-reader reuse are separate unimplemented work; this correction alone does not qualify the installed HTTP/2 path or reduce the checks inside the production credential source.

The accepted template is the API-returned defaulted Deployment template. Comparison retains every PodSpec/security/mount/token field and template label/annotation. It normalizes only the deprecated service-account alias and Pod-only zero priority/default preemption/default service-links scalars. It removes exactly the qualified ReplicaSet controller hash and actual node assignment for comparison. Both 300-second not-ready/unreachable tolerations are explicit. Automount is false; the projected service-account token is explicit and dynamic, with its entire specification pinned. Init/ephemeral/sidecar injection, different mounts, privilege, image or arguments fail closed.

ConfigMap/Secret metadata reads bind exact UID and resourceVersion. Settings cannot include their own future UID/RV: those are independent constructor pins plus a current exact immutable source read. Changes to SQL/provider input revisions require an accepted new configuration/rollout; they do not silently refresh a running profile.

PartialObjectMetadata limits returned data, not Kubernetes privileges. `dedicatedToAPI` is an immutable installer-owned whole-object approval required for Secret references and forbidden for ConfigMap references. The installer must construct role-owned dedicated objects and independently accept those exact names/UIDs. Mounting one file does not establish ownership of other keys. Native grants permit GET on only these whole approved objects; unrelated GET and namespace LIST must fail. No payload hash is used, and the reader does not fetch Secret payloads. A metadata reader with broader credentials would be an unqualified composition.

The optional owner policy branch admits exact capacity-account CREATE on the main CapacityReservation and exact capacity/execution-account UPDATE on its status subresource. It grants no RBAC and no main UPDATE, deletion, Secret/token/input mutation or arbitrary CRD privilege. Independently pinned StartAdmission enforces the original immutable binding, Ready and one StartCommitted transition. Legacy bare-Pod and omitted owner-capability bytes are unchanged.

## SQL and components

`OwnerEnrollments.ReadContextStartOwners` reuses the existing current owner read facet. It locks recovery before owner configuration, reads at most seventeen candidates, rejects overflow and returns no addresses or certificates. Only audited enrolled server-purpose processes with a current activated certificate are candidates. Exact route/TLS checks remain mandatory. The query adds no schema, role, durable row or authority producer.

C-20 owns closed wire DTOs and `internal/transport/contextstart`. C-21 owns the existing adapter/bootstrap composition. Application/domain imports remain inward; adapters never import transport handlers in production. The bootstrap connections supervisor owns joined shutdown, not a new durable queue.

## Qualification and remaining work

Staged focused races have exercised actual loopback TLS1.3/HTTP2 with process-owned keys, seven regional identity round trips plus final hub check, owner cancellation, original-work expiry rejecting a late positive result, and EOF joining final current identity. Sources/registries/routes/API process in those tests are explicitly synthetic. Separate stream races cover passive first wait, shorter peer expiry interrupting a blocked body pipe, finite bidirectional frames and blocked identity cancellation. Signed-work tests include wrong purpose/profile/process, closed encoding, maximum strings and retention of the original trust/peer deadline. The earlier overlap condition and settings-size defect both have preserved failing-before evidence.

`TestConnectorAPIProcessWithRealKubernetes` has not passed the complete local-start sequence: real guarded Deployment/Pod defaulting, TokenReview/SSR, source/input pins, named Secret grants and both local status transitions. Its accepted connector source, CA/registry and first preparation claim are explicit fixture inputs. The preserved third native run passed the process/defaulted-input checks and named Secret/foreign-read and changed-input negatives. It created one CapacityReservation, then exhausted the original PrepareStart bound at 4.995665377 seconds before Ready. The fixture now records static per-phase API counts and elapsed request time, never credentials or payloads; the corrected timing result remains unrun. Actual API/QPS cost must fit the existing five-second intervals; whole-test duration is not evidence of a particular authority timeout.

Pending qualification: actual native reader/start behavior; real SQL owner enumeration; whole signed exchange plus SQL52 admission/intent, regional collection/storage, independent publication and exact native download; failure/unknown partitions across those components. The complete per-frame process/peer checks can amplify API work and need measured same-request timing. Proof reuse is limited to the original interval and current checks above; no deadline or client QPS limit is enlarged.

Missing production inputs remain dedicated work-signing key/sign-only hub credential, verify-only regional trust, exact connector API profile/input ownership/RBAC, protected installed composition and regional command startup. Existing initial installation does not yet provision those inputs. The first installed context investigation remains unavailable until these producers and the combined runtime path are implemented and qualified.
