package kms

import (
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestOwnerProviderLeaseExpiresDuringActualTLSBody(t *testing.T) {
	releaseServer := make(chan struct{})
	var requests, released atomic.Int32
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		if r.Method != http.MethodPost || r.Header.Get("X-Vault-Token") != "only-this-original-lease" {
			w.WriteHeader(http.StatusForbidden)
			return
		}
		w.WriteHeader(http.StatusOK)
		w.(http.Flusher).Flush()
		select {
		case <-r.Context().Done():
		case <-releaseServer:
		}
	}))
	defer server.Close()
	defer close(releaseServer)
	until := time.Now().Add(350 * time.Millisecond)
	base := server.Client().Transport.(*http.Transport).Clone()
	defer base.CloseIdleConnections()
	transport := &ownerProviderLeaseTransport{base: base, now: time.Now, source: func(context.Context) (ownerProviderLease, error) {
		return ownerProviderLease{token: []byte("only-this-original-lease"), until: until, release: func() { released.Add(1) }}, nil
	}}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	request, _ := http.NewRequestWithContext(ctx, http.MethodPost, server.URL, strings.NewReader("{}"))
	response, err := transport.RoundTrip(request)
	if err != nil {
		t.Fatal("original lease did not reach TLS headers", err)
	}
	defer response.Body.Close()
	if _, err = io.ReadAll(response.Body); err == nil || ctx.Err() != nil || time.Now().Before(until) {
		t.Fatal("response escaped original credential end or used caller timeout", err)
	}
	if requests.Load() != 1 || released.Load() != 0 {
		t.Fatal("body failure replayed effect or released before actual close")
	}
	if err = response.Body.Close(); err != nil || released.Load() != 1 {
		t.Fatal("original borrow was not joined exactly once", err)
	}
}

type ownerLeaseRoundTrip func(*http.Request) (*http.Response, error)

func (f ownerLeaseRoundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

type ownerLeaseBlockingClose struct {
	entered chan struct{}
	finish  chan struct{}
	closes  atomic.Int32
}

func (*ownerLeaseBlockingClose) Read([]byte) (int, error) { return 0, io.EOF }
func (b *ownerLeaseBlockingClose) Close() error {
	if b.closes.Add(1) == 1 {
		close(b.entered)
	}
	<-b.finish
	return nil
}

func TestOwnerProviderLeaseRetainsBorrowUntilBlockedCloseJoins(t *testing.T) {
	body := &ownerLeaseBlockingClose{entered: make(chan struct{}), finish: make(chan struct{})}
	var releases atomic.Int32
	transport := &ownerProviderLeaseTransport{now: time.Now, source: func(context.Context) (ownerProviderLease, error) {
		return ownerProviderLease{token: []byte("original-token"), until: time.Now().Add(time.Second), release: func() { releases.Add(1) }}, nil
	}, base: ownerLeaseRoundTrip(func(r *http.Request) (*http.Response, error) {
		if r.GetBody != nil {
			t.Fatal("effect acquired replay body")
		}
		return &http.Response{StatusCode: http.StatusOK, Body: body}, nil
	})}
	request, _ := http.NewRequest(http.MethodPost, "https://provider.invalid/v1/transit/encrypt/fixed", strings.NewReader("{}"))
	response, err := transport.RoundTrip(request)
	if err != nil {
		t.Fatal(err)
	}
	done := make(chan struct{})
	go func() { _ = response.Body.Close(); close(done) }()
	<-body.entered
	if releases.Load() != 0 {
		t.Error("closing borrow stopped counting before closure joined")
	}
	close(body.finish)
	<-done
	_ = response.Body.Close()
	if releases.Load() != 1 || body.closes.Load() != 1 {
		t.Fatal("closure or borrow release repeated")
	}
}

func TestOwnerProviderLeaseRejectsExpiredBeforeEffectAndKeepsCallerEnd(t *testing.T) {
	for _, expired := range []bool{true, false} {
		var calls, releases atomic.Int32
		callerEnd := time.Now().Add(time.Second)
		ctx, cancel := context.WithDeadline(context.Background(), callerEnd)
		until := callerEnd.Add(time.Second)
		if expired {
			until = time.Now().Add(-time.Second)
		}
		transport := &ownerProviderLeaseTransport{now: time.Now, source: func(context.Context) (ownerProviderLease, error) {
			return ownerProviderLease{token: []byte("original-token"), until: until, release: func() { releases.Add(1) }}, nil
		}, base: ownerLeaseRoundTrip(func(r *http.Request) (*http.Response, error) {
			calls.Add(1)
			if end, ok := r.Context().Deadline(); !ok || !end.Equal(callerEnd) {
				t.Error("credential lease extended earlier caller end")
			}
			return &http.Response{StatusCode: http.StatusOK, Body: io.NopCloser(strings.NewReader("{}"))}, nil
		})}
		request, _ := http.NewRequestWithContext(ctx, http.MethodPost, "https://provider.invalid/v1/transit/encrypt/fixed", nil)
		response, err := transport.RoundTrip(request)
		if expired {
			if err == nil || calls.Load() != 0 || releases.Load() != 1 {
				t.Error("expired credential reached effect or leaked borrow")
			}
		} else if err != nil {
			t.Error(err)
		} else {
			_ = response.Body.Close()
		}
		cancel()
	}
}
