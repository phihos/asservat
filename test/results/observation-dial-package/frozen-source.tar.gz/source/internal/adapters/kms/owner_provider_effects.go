package kms

import (
	"context"
	"crypto/x509"
	"errors"
	"net/http"
	"net/url"
	"time"

	"asservat.local/asservat/internal/adapters/mtls"
	"asservat.local/asservat/internal/contracts"
	value "asservat.local/asservat/internal/domain/fleet"
	bao "github.com/openbao/openbao/api/v2"
)

// This private composition has no runtime selector. Its eventual installed
// constructor must supply the concrete original native/source/recovery proof.
// All four adapters and lifetime owners derive from this same validated recipe;
// an unrelated already-authenticated slot cannot be inserted by a caller.
type ownerProviderEffects struct {
	lifetimes      *ownerProviderLifetimes
	seal           *Sealer
	open           *Opener
	server, client *OwnerCertificateIssuer
}

func newOwnerProviderEffects(ctx context.Context, input contracts.OwnerDeployment, profile contracts.OwnerProviderAuthentication, pool value.OwnerPool, issuerRoots *x509.CertPool, jwt TokenSource, proof ownerProviderCurrent, client *http.Client, concurrency int, now func() time.Time) (*ownerProviderEffects, error) {
	if now == nil || !pool.Valid() || pool.InstallationID != input.InstallationID || pool.ClusterID != input.ClusterID || pool.Namespace != input.Namespace.Name || pool.NamespaceUID != input.Namespace.UID || pool.ServiceAccount != profile.ServiceAccount.Name || pool.AccountUID != profile.ServiceAccount.UID {
		return nil, ErrKeyService
	}
	verifier, err := mtls.NewOwnerPeerVerifierForPool(issuerRoots, pool, now)
	if err != nil {
		return nil, err
	}
	slots, err := newOwnerProviderLifetimes(ctx, input, profile, jwt, proof, client, concurrency, now)
	if err != nil {
		return nil, err
	}
	out := &ownerProviderEffects{lifetimes: slots}
	complete := false
	defer func() {
		if !complete {
			_ = out.close(context.Background())
		}
	}()
	wrap, err := newOwnerProviderEffectClient(slots.auditWrap, input.KeyService.AuditMount+"/encrypt/"+input.KeyService.AuditKey)
	if err != nil {
		return nil, err
	}
	out.seal = &Sealer{client: wrap, mount: input.KeyService.AuditMount, key: input.KeyService.AuditKey, reference: input.KeyService.AuditMount + "/" + input.KeyService.AuditKey}
	unwrap, err := newOwnerProviderEffectClient(slots.auditUnwrap, input.KeyService.AuditMount+"/decrypt/"+input.KeyService.AuditKey)
	if err != nil {
		return nil, err
	}
	out.open = &Opener{client: unwrap, mount: input.KeyService.AuditMount, key: input.KeyService.AuditKey, reference: input.KeyService.AuditMount + "/" + input.KeyService.AuditKey}
	for _, fixed := range []struct {
		slot        *ownerProviderLifetime
		usage, role string
		target      **OwnerCertificateIssuer
	}{
		{slots.serverSign, "server", input.KeyService.ServerRole, &out.server},
		{slots.clientSign, "client", input.KeyService.ClientRole, &out.client},
	} {
		path := input.KeyService.PKIMount + "/sign/" + fixed.role
		c, e := newOwnerProviderEffectClient(fixed.slot, path)
		if e != nil {
			return nil, e
		}
		issuer := &OwnerCertificateIssuer{client: c, path: path, installation: pool.InstallationID, cluster: pool.ClusterID, epoch: pool.IssuerEpoch, usage: fixed.usage, verify: verifier, now: now}
		if pool.NativeBootstrap != "" {
			issuer.pool = pool
		}
		*fixed.target = issuer
	}
	if ctx.Err() != nil {
		return nil, ErrKeyService
	}
	complete = true
	return out, nil
}

func (s *ownerProviderEffects) close(ctx context.Context) error {
	if s == nil || s.lifetimes == nil {
		return ErrKeyService
	}
	if err := s.lifetimes.close(ctx); err != nil {
		return err
	}
	// The actual calls/bodies joined before their idle transports are released.
	// A prior timeout retains these clients and may be joined by a later close.
	s.seal.Close()
	s.open.Close()
	s.server.Close()
	s.client.Close()
	return nil
}

func newOwnerProviderEffectClient(slot *ownerProviderLifetime, path string) (*bao.Client, error) {
	if slot == nil || slot.control == nil || slot.control.http == nil {
		return nil, ErrKeyService
	}
	control := slot.control
	endpoint, err := url.Parse(control.endpoint)
	if err != nil {
		return nil, ErrKeyService
	}
	base, ok := control.http.Transport.(*http.Transport)
	if !ok {
		return nil, ErrKeyService
	}
	// The control constructor already discarded ambient proxies and custom TLS
	// hooks and pinned the original profile's exact provider roots. Clone that
	// transport, never the unvalidated caller's client or another purpose's token.
	transport := base.Clone()
	leased := &ownerProviderLeaseTransport{base: transport, source: slot.borrow, now: control.now}
	httpClient := &http.Client{Timeout: 10 * time.Second, Transport: &ownerProviderEffectTransport{next: leased, endpoint: *endpoint, path: "/v1/" + path}, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	config := bao.NewConfig()
	config.Address, config.Timeout, config.MaxRetries = control.endpoint, 10*time.Second, 0
	config.HttpClient = httpClient
	c, err := bao.NewClient(config)
	if err != nil {
		transport.CloseIdleConnections()
		return nil, ErrKeyService
	}
	c.SetToken("")
	c.SetCheckRedirect(func(*http.Request, []*http.Request) error { return errors.New("KMS redirects disabled") })
	return c, nil
}

// The maintained Bao codecs are used unchanged, but each private client can
// disclose its leased credential to only its fixed original effect endpoint.
type ownerProviderEffectTransport struct {
	next     *ownerProviderLeaseTransport
	endpoint url.URL
	path     string
}

func (t *ownerProviderEffectTransport) CloseIdleConnections() {
	if t != nil && t.next != nil {
		t.next.CloseIdleConnections()
	}
}
func (t *ownerProviderEffectTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	if t == nil || t.next == nil || r == nil || r.URL == nil || r.Method != http.MethodPost || r.URL.Scheme != t.endpoint.Scheme || r.URL.Host != t.endpoint.Host || r.URL.User != nil || r.URL.RawQuery != "" || r.URL.ForceQuery || r.URL.Fragment != "" || r.URL.EscapedPath() != t.path || r.Host != "" && r.Host != t.endpoint.Host {
		return nil, ErrKeyService
	}
	return t.next.RoundTrip(r)
}

func (s *ownerProviderEffects) joinClosed() {
	if s == nil || s.lifetimes == nil {
		return
	}
	s.lifetimes.joinClosed()
	s.seal.Close()
	s.open.Close()
	s.server.Close()
	s.client.Close()
}
