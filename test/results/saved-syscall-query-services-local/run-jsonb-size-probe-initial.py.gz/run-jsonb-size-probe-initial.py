from pathlib import Path
import csv,hashlib,json,subprocess,sys,time,uuid
root=Path('/home/phil/Projekte/asservat-saved-syscall-query');cache=Path('/home/phil/.cache/asservat-build/saved-syscall-query');folder=cache/'jsonb-size-probe';folder.mkdir(exist_ok=True)
expected=sys.argv[1];head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head==expected
image='postgres@sha256:afc7e2d441324c0388fa80c3d24f733b4194a4eb7f47dd8ee2b08eb1a24a647c';name='asservat-syscall-query-size-'+uuid.uuid4().hex[:12];commands=[];h=lambda b:hashlib.sha256(b).hexdigest()
def run(args,input=None,timeout=30,required=True):
 p=subprocess.run(args,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout);commands.append({'argv':args,'exit':p.returncode,'stdoutSHA256':h(p.stdout),'stderrSHA256':h(p.stderr)})
 if required and p.returncode:raise RuntimeError('probe command failed: '+args[0]+' '+str(p.returncode))
 return p
started=False;exit_code=1;cleanup=None
try:
 inspect=run(['docker','image','inspect','--format','{{.Id}}',image]);(folder/'image-id.txt').write_bytes(inspect.stdout)
 start=run(['docker','run','--rm','-d','--name',name,'--network','none','--read-only','--user','postgres','--tmpfs','/tmp:rw,nosuid,nodev,size=32m','--tmpfs','/var/run/postgresql:rw,nosuid,nodev,size=16m,mode=1777','--tmpfs','/var/lib/postgresql:rw,nosuid,nodev,size=256m,mode=1777','-e','POSTGRES_PASSWORD=synthetic-only','-e','POSTGRES_DB=size_probe',image,'-c','shared_buffers=16MB','-c','max_connections=8']);started=True;(folder/'container-id.txt').write_bytes(start.stdout)
 for attempt in range(100):
  ready=run(['docker','exec',name,'pg_isready','-U','postgres','-d','size_probe'],required=False)
  if ready.returncode==0:break
  time.sleep(.1)
 else:raise RuntimeError('owned size-probe PostgreSQL did not become ready')
 sql=(cache/'full-valid-jsonb-sizes.sql').read_bytes();result=run(['docker','exec','-i',name,'psql','-X','-A','-t','-F','\t','-U','postgres','-d','size_probe'],input=sql);(folder/'sizes.tsv').write_bytes(result.stdout);(folder/'psql.stderr').write_bytes(result.stderr)
 rows=list(csv.reader(result.stdout.decode().strip().splitlines(),delimiter='\t'));assert len(rows)==20, len(rows)
 for row in rows:assert len(row)==5 and row[4]=='t' and int(row[2])<=int(row[3]),row
 exit_code=0
finally:
 if started:
  cleanup=run(['docker','rm','-f','-v',name],required=False);(folder/'cleanup.stdout').write_bytes(cleanup.stdout);(folder/'cleanup.stderr').write_bytes(cleanup.stderr)
  if cleanup.returncode!=0:exit_code=1
 remaining=run(['docker','ps','-a','--filter','name='+name,'--format','{{.ID}} {{.Names}}']);(folder/'remaining.txt').write_bytes(remaining.stdout)
 if remaining.stdout.strip():exit_code=1
 actualHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 report={'scope':'Content-free PostgreSQL JSONB size probe of20 independently Go-validated synthetic complete typed values. No runtime-role/lifecycle/installed authority qualification.','sourceHead':head,'sourceHeadUnchanged':head==actualHead,'image':image,'imageID':(folder/'image-id.txt').read_text().strip() if (folder/'image-id.txt').exists() else None,'sqlSHA256':h((cache/'full-valid-jsonb-sizes.sql').read_bytes()),'fixtureManifestSHA256':h((cache/'full-valid-size-fixtures-manifest.json').read_bytes()),'actualExit':exit_code,'cleanupExit':cleanup.returncode if cleanup else None,'ownedContainersRemaining':remaining.stdout.decode().strip(),'commands':commands}
 if (folder/'sizes.tsv').exists():report['sizes']=[{'name':x[0],'compactBytes':int(x[1]),'jsonbBytes':int(x[2]),'bound':int(x[3]),'fits':x[4]=='t'} for x in csv.reader((folder/'sizes.tsv').read_text().strip().splitlines(),delimiter='\t')]
 (folder/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['sourceHead','actualExit','cleanupExit','ownedContainersRemaining']},indent=2))
sys.exit(exit_code)
