import json,os,pathlib,resource,subprocess,sys,time
base=pathlib.Path(__file__).resolve().parent
shape=sys.argv[1]
assert shape in ("dense","long","origins")
env=dict(os.environ,TMPDIR="/home/phil/.cache/asservat-build/tmp",ASSERVAT_LOG_STREAM_GENERATE=str(base/shape),ASSERVAT_LOG_STREAM_SHAPE=shape)
start=time.monotonic()
with (base/shape/"generation.log").open("wb") as log:
 result=subprocess.run([str(base/"build/reader.test"),"-test.run","^TestLogQueryEncryptedProcess$","-test.count=1","-test.v"],env=env,stdout=log,stderr=subprocess.STDOUT)
u=resource.getrusage(resource.RUSAGE_CHILDREN)
report=dict(shape=shape,exit=result.returncode,elapsedSeconds=time.monotonic()-start,peakRSSKiB=u.ru_maxrss,userSeconds=u.ru_utime,systemSeconds=u.ru_stime,scope="Synthetic fixture producer outside measured worker")
(base/shape/"generation-report.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))
sys.exit(result.returncode)
