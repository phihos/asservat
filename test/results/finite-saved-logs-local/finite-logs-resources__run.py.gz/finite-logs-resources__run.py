import hashlib,json,pathlib,re,subprocess,time
base=pathlib.Path(__file__).resolve().parent
image=subprocess.check_output(["docker","image","inspect","asservat-logs-resource:local-5342efc5","--format","{{.Id}}"],text=True).strip()
report={"imageID":image,"binarySHA256":hashlib.sha256((base/"build/reader.test").read_bytes()).hexdigest(),"scope":"Component encrypted reader/parser plus in-process TLS source; synthetic accepted authority/keys/receipts; not installed or SQL/key-service qualification","cases":[]}
for shape in ("dense","long","origins"):
 name="asservat-log-resource-"+shape+"-"+report["binarySHA256"][:10]
 cid=None
 entry={"shape":shape,"name":name}
 start=time.monotonic()
 try:
  command=["docker","create","--name",name,"--label","asservat.test=finite-logs-resource","--network=none","--read-only","--cap-drop=ALL","--security-opt=no-new-privileges","--pids-limit=64","--memory=256m","--memory-swap=256m","--cpus=0.5","--mount","type=bind,src="+str(base/shape)+",dst=/fixture,readonly","--env","ASSERVAT_LOG_STREAM_FIXTURE=/fixture",image,"-test.run","^TestLogQueryEncryptedProcess$","-test.count=1","-test.v"]
  entry["command"]=command
  cid=subprocess.check_output(command,text=True,stderr=subprocess.STDOUT).strip()
  entry["containerID"]=cid
  subprocess.run(["docker","start",cid],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  waited=subprocess.run(["docker","wait",cid],capture_output=True,text=True,timeout=45)
  entry["waitCommandExit"]=waited.returncode
  entry["processExit"]=int(waited.stdout.strip())
  logs=subprocess.check_output(["docker","logs",cid],stderr=subprocess.STDOUT)
  (base/shape/"worker.log").write_bytes(logs)
  details=json.loads(subprocess.check_output(["docker","inspect",cid]))[0]
  (base/shape/"container-inspect.json").write_text(json.dumps(details,indent=2)+"\n")
  entry["oomKilled"]=details["State"]["OOMKilled"]
  entry["elapsedSeconds"]=time.monotonic()-start
  metrics={}
  for line in logs.decode().splitlines():
   m=re.search(r'worker cgroup ([a-z.]+)=(".*")$',line)
   if m:metrics[m[1]]=json.loads(m[2])
  entry["cgroup"]=metrics
  entry["passed"]=entry["processExit"]==0 and not entry["oomKilled"] and metrics.get("memory.max","").strip()=="268435456" and metrics.get("memory.swap.max","").strip()=="0" and metrics.get("cpu.max","").strip()=="50000 100000" and 'threeKeys=true valid=true refusal=false' in logs.decode()
 except Exception as e:
  entry["error"]=str(e)
  entry["passed"]=False
 finally:
  if cid:
   cleanup=subprocess.run(["docker","rm","-f",cid],capture_output=True,text=True)
   entry["cleanupExit"]=cleanup.returncode
  report["cases"].append(entry)
  (base/"report.json").write_text(json.dumps(report,indent=2)+"\n")
  print(json.dumps(entry),flush=True)
report["allPassed"]=all(c["passed"] and c.get("cleanupExit")==0 for c in report["cases"])
(base/"report.json").write_text(json.dumps(report,indent=2)+"\n")
raise SystemExit(0 if report["allPassed"] else 1)
