-- +goose Up
-- Protected bootstrap creates the root/epoch and finite ceilings. Runtime
-- credentials cannot create/change this configuration. Restore rotates epoch.
CREATE TABLE browser_session_root (
 id uuid PRIMARY KEY,
 epoch uuid NOT NULL,
 enabled boolean NOT NULL DEFAULT false,
 max_logins integer NOT NULL CHECK(max_logins BETWEEN 1 AND 10000),
 max_sessions integer NOT NULL CHECK(max_sessions BETWEEN 1 AND 100000),
 max_logout_events integer NOT NULL CHECK(max_logout_events BETWEEN 1 AND 100000)
);
CREATE TABLE browser_login (
 root_id uuid NOT NULL REFERENCES browser_session_root(id),
 epoch uuid NOT NULL,
 id bytea NOT NULL CHECK(octet_length(id)=32),
 browser bytea NOT NULL CHECK(octet_length(browser)=32),
 ciphertext bytea NOT NULL CHECK(octet_length(ciphertext) BETWEEN 1 AND 262144),
 created_at timestamptz NOT NULL,
 expires_at timestamptz NOT NULL,
 PRIMARY KEY(root_id,id),
 CHECK(expires_at>created_at AND expires_at<=created_at+interval '5 minutes')
);
CREATE INDEX browser_login_expiry ON browser_login(root_id,expires_at);
CREATE TABLE browser_session (
 root_id uuid NOT NULL REFERENCES browser_session_root(id),
 epoch uuid NOT NULL,
 id bytea NOT NULL CHECK(octet_length(id)=32),
 issuer text NOT NULL CHECK(octet_length(issuer) BETWEEN 1 AND 2048),
 client_id text NOT NULL CHECK(octet_length(client_id) BETWEEN 1 AND 256),
 subject text NOT NULL CHECK(octet_length(subject) BETWEEN 1 AND 256),
 provider_session text NOT NULL CHECK(octet_length(provider_session) BETWEEN 1 AND 256),
 ciphertext bytea NOT NULL CHECK(octet_length(ciphertext) BETWEEN 1 AND 262144),
 created_at timestamptz NOT NULL,
 authenticated_at timestamptz NOT NULL,
 expires_at timestamptz NOT NULL,
 refresh_at timestamptz NOT NULL,
 version bigint NOT NULL CHECK(version>0),
 refresh_claim bytea CHECK(refresh_claim IS NULL OR octet_length(refresh_claim)=32),
 claim_until timestamptz,
 PRIMARY KEY(root_id,id),
 CHECK(expires_at>created_at AND expires_at<=created_at+interval '24 hours'),
 CHECK(authenticated_at<=created_at),
 CHECK(refresh_at>created_at AND refresh_at<=expires_at),
 CHECK((refresh_claim IS NULL)=(claim_until IS NULL))
);
CREATE INDEX browser_session_expiry ON browser_session(root_id,expires_at);
CREATE INDEX browser_session_subject ON browser_session(root_id,issuer,client_id,subject);
CREATE INDEX browser_session_provider ON browser_session(root_id,issuer,client_id,provider_session);
CREATE TABLE browser_logout (
 root_id uuid NOT NULL REFERENCES browser_session_root(id),
 epoch uuid NOT NULL,
 id bytea NOT NULL CHECK(octet_length(id)=32),
 issuer text NOT NULL CHECK(octet_length(issuer) BETWEEN 1 AND 2048),
 client_id text NOT NULL CHECK(octet_length(client_id) BETWEEN 1 AND 256),
 subject text NOT NULL CHECK(octet_length(subject)<=256),
 provider_session text NOT NULL CHECK(octet_length(provider_session)<=256),
 issued_at timestamptz NOT NULL,
 expires_at timestamptz NOT NULL,
 PRIMARY KEY(root_id,id),
 CHECK(subject<>'' OR provider_session<>''),
 CHECK(expires_at>issued_at AND expires_at<=issued_at+interval '25 hours')
);
CREATE INDEX browser_logout_expiry ON browser_logout(root_id,expires_at);
-- Credentials are short-lived operational state, never immutable evidence.
-- No down migration may restore consumed login/refresh credentials.;
-- +goose Up
-- Browser configuration is Kubernetes-owned. A missing/stale projection must
-- not preserve the fixture-era boolean as permission to use a session.
ALTER TABLE browser_session_root
 ADD COLUMN source_uid text CHECK(source_uid IS NULL OR octet_length(source_uid) BETWEEN 1 AND 64),
 ADD COLUMN source_generation bigint CHECK(source_generation IS NULL OR source_generation BETWEEN 1 AND 2147483647),
 ADD COLUMN source_digest bytea CHECK(source_digest IS NULL OR octet_length(source_digest)=32),
 ADD COLUMN observed_at timestamptz,
 ADD COLUMN fresh_until timestamptz,
 ADD COLUMN issuer text CHECK(issuer IS NULL OR octet_length(issuer) BETWEEN 1 AND 2048),
 ADD COLUMN client_id text CHECK(client_id IS NULL OR octet_length(client_id) BETWEEN 1 AND 256),
 ADD COLUMN origin text CHECK(origin IS NULL OR octet_length(origin) BETWEEN 1 AND 2048),
 ADD COLUMN max_lifetime_seconds integer CHECK(max_lifetime_seconds IS NULL OR max_lifetime_seconds BETWEEN 60 AND 86400),
 ADD CONSTRAINT browser_settings_complete CHECK(
  (source_uid IS NULL AND source_generation IS NULL AND source_digest IS NULL AND observed_at IS NULL AND fresh_until IS NULL AND issuer IS NULL AND client_id IS NULL AND origin IS NULL AND max_lifetime_seconds IS NULL) OR
  (source_uid IS NOT NULL AND source_generation IS NOT NULL AND source_digest IS NOT NULL AND observed_at IS NOT NULL AND fresh_until IS NOT NULL AND issuer IS NOT NULL AND client_id IS NOT NULL AND origin IS NOT NULL AND max_lifetime_seconds IS NOT NULL AND fresh_until>observed_at AND fresh_until<=observed_at+interval '5 seconds')
 );
UPDATE browser_session_root SET enabled=false;
CREATE TABLE browser_session_epoch (
 root_id uuid NOT NULL REFERENCES browser_session_root(id),
 epoch uuid NOT NULL,
 source_generation bigint NOT NULL CHECK(source_generation BETWEEN 0 AND 2147483647),
 PRIMARY KEY(root_id,epoch)
);
INSERT INTO browser_session_epoch(root_id,epoch,source_generation) SELECT id,epoch,0 FROM browser_session_root;
-- Existing unqualified roots are fenced. Their ephemeral login/session state
-- is revoked on the first qualified settings acceptance; evidence is untouched.;
INSERT INTO browser_session_root(id,epoch,enabled,max_logins,max_sessions,max_logout_events,issuer,client_id,origin,source_uid,source_generation,source_digest,observed_at,fresh_until,max_lifetime_seconds) VALUES('10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid,false,1000,1000,1000,'https://id.example.test','console','https://console.example.test','synthetic-settings',1,sha256('synthetic-settings'::bytea),statement_timestamp()-interval '2 minutes',statement_timestamp()-interval '119 seconds',3600);
INSERT INTO browser_login(root_id,epoch,id,browser,ciphertext,created_at,expires_at)
   SELECT '10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid,sha256(convert_to('expired-login-'||i,'UTF8')),sha256(convert_to('browser-'||i,'UTF8')),'synthetic-encrypted-login',statement_timestamp()-interval '2 minutes',statement_timestamp()-interval '1 minute' FROM generate_series(1,300)i;
INSERT INTO browser_session(root_id,epoch,id,issuer,client_id,subject,provider_session,ciphertext,created_at,authenticated_at,expires_at,refresh_at,version)
   SELECT '10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid,sha256(convert_to('expired-session-'||i,'UTF8')),'https://id.example.test','console','synthetic-user','synthetic-provider','synthetic-encrypted-session',statement_timestamp()-interval '2 hours',statement_timestamp()-interval '2 hours',statement_timestamp()-interval '1 hour',statement_timestamp()-interval '90 minutes',1 FROM generate_series(1,300)i;
INSERT INTO browser_logout(root_id,epoch,id,issuer,client_id,subject,provider_session,issued_at,expires_at)
   SELECT '10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid,sha256(convert_to('expired-logout-'||i,'UTF8')),'https://id.example.test','console','synthetic-user','',statement_timestamp()-interval '2 hours',statement_timestamp()-interval '1 hour' FROM generate_series(1,300)i;
INSERT INTO browser_login(root_id,epoch,id,browser,ciphertext,created_at,expires_at) VALUES('10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid,sha256(convert_to('10000000-0000-4000-8000-000000000002'::uuid::uuid::text,'UTF8')),sha256(convert_to('10000000-0000-4000-8000-000000000002'::uuid::uuid::text,'UTF8')),'synthetic-live-login',statement_timestamp(),statement_timestamp()+interval '4 minutes');
INSERT INTO browser_session(root_id,epoch,id,issuer,client_id,subject,provider_session,ciphertext,created_at,authenticated_at,expires_at,refresh_at,version) VALUES('10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid,sha256(convert_to('10000000-0000-4000-8000-000000000002'::uuid::uuid::text,'UTF8')),'https://id.example.test','console','synthetic-user','synthetic-provider','synthetic-live-session',statement_timestamp(),statement_timestamp(),statement_timestamp()+interval '1 hour',statement_timestamp()+interval '1 minute',1);
INSERT INTO browser_login(root_id,epoch,id,browser,ciphertext,created_at,expires_at) VALUES('10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000003'::uuid,sha256(convert_to('10000000-0000-4000-8000-000000000003'::uuid::uuid::text,'UTF8')),sha256(convert_to('10000000-0000-4000-8000-000000000003'::uuid::uuid::text,'UTF8')),'synthetic-live-login',statement_timestamp(),statement_timestamp()+interval '4 minutes');
INSERT INTO browser_session(root_id,epoch,id,issuer,client_id,subject,provider_session,ciphertext,created_at,authenticated_at,expires_at,refresh_at,version) VALUES('10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000003'::uuid,sha256(convert_to('10000000-0000-4000-8000-000000000003'::uuid::uuid::text,'UTF8')),'https://id.example.test','console','synthetic-user','synthetic-provider','synthetic-live-session',statement_timestamp(),statement_timestamp(),statement_timestamp()+interval '1 hour',statement_timestamp()+interval '1 minute',1);
INSERT INTO browser_session(root_id,epoch,id,issuer,client_id,subject,provider_session,ciphertext,created_at,authenticated_at,expires_at,refresh_at,version,refresh_claim,claim_until)
   SELECT '10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid,sha256(convert_to(x,'UTF8')),'https://id.example.test','console','synthetic-user','synthetic-provider','synthetic-claimed-session',statement_timestamp()-interval '1 minute',statement_timestamp()-interval '1 minute',statement_timestamp()+interval '1 hour',statement_timestamp()+interval '1 minute',1,sha256(convert_to(x,'UTF8')),statement_timestamp()+d FROM (VALUES('abandoned',interval '-1 second'),('inflight',interval '5 minutes'))v(x,d);
SELECT count(*) AS before_count FROM browser_session;
PREPARE prune(uuid,uuid) AS DELETE FROM browser_session AS target WHERE target.root_id=$1 AND target.id IN (SELECT candidate.id FROM browser_session AS candidate WHERE candidate.root_id=$1 AND (candidate.expires_at<=clock_timestamp() OR candidate.epoch<>$2 OR candidate.claim_until<=clock_timestamp()) ORDER BY candidate.expires_at,candidate.id LIMIT 256 FOR UPDATE SKIP LOCKED);
EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) EXECUTE prune('10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid);
SELECT count(*) AS after_count FROM browser_session;
